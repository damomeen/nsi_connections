/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.util;

import java.math.BigInteger;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;

import javax.xml.bind.JAXBElement;
import javax.xml.namespace.QName;
import javax.xml.ws.Holder;

import net.glambda.pathfinder.Path;
import net.glambda.pathfinder.PathFindingCriteria;
import net.glambda.pathfinder.PathFindingResult;
import net.glambda.pathfinder.Range;
import net.glambda.pathfinder.STP;
import net.glambda.rms.types.CriteriaBase;
import net.glambda.rms.types.EthernetCriteria;
import net.glambda.rms.types.LambdaCriteria;
import net.glambda.rms.types.ODUCriteria;
import net.glambda.rms.types.TransferCriteria;
import net.glambda.schemas._2013._12.services.dopn.LambdaType;
import net.glambda.schemas._2013._12.services.dopn.ODUType;
import net.glambda.schemas._2013._12.services.dopn.TransferType;
import oasis.names.tc.saml._2_0.assertion.AttributeStatementType;
import oasis.names.tc.saml._2_0.assertion.AttributeType;

import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.types.ChildRecursiveListType;
import org.ogf.schemas.nsi._2013._12.connection.types.ChildRecursiveType;
import org.ogf.schemas.nsi._2013._12.connection.types.ChildSummaryListType;
import org.ogf.schemas.nsi._2013._12.connection.types.ChildSummaryType;
import org.ogf.schemas.nsi._2013._12.connection.types.ConnectionStatesType;
import org.ogf.schemas.nsi._2013._12.connection.types.DataPlaneStatusType;
import org.ogf.schemas.nsi._2013._12.connection.types.ErrorEventType;
import org.ogf.schemas.nsi._2013._12.connection.types.EventEnumType;
import org.ogf.schemas.nsi._2013._12.connection.types.MessageDeliveryTimeoutRequestType;
import org.ogf.schemas.nsi._2013._12.connection.types.NotificationBaseType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryNotificationConfirmedType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryRecursiveResultCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryRecursiveResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryConfirmedType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryResultCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationConfirmCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReserveConfirmedType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReserveTimeoutRequestType;
import org.ogf.schemas.nsi._2013._12.connection.types.ScheduleType;
import org.ogf.schemas.nsi._2013._12.framework.headers.CommonHeaderType;
import org.ogf.schemas.nsi._2013._12.framework.headers.SessionSecurityAttrType;
import org.ogf.schemas.nsi._2013._12.framework.types.ServiceExceptionType;
import org.ogf.schemas.nsi._2013._12.framework.types.TypeValuePairListType;
import org.ogf.schemas.nsi._2013._12.framework.types.TypeValuePairType;
import org.ogf.schemas.nsi._2013._12.framework.types.VariablesType;
import org.ogf.schemas.nsi._2013._12.services.point2point.P2PServiceBaseType;
import org.ogf.schemas.nsi._2013._12.services.types.DirectionalityType;
import org.ogf.schemas.nsi._2013._12.services.types.OrderedStpType;
import org.ogf.schemas.nsi._2013._12.services.types.StpListType;

public class NSITextDump {

    private static final String NEWLINE = System.getProperty("line.separator");
    private static final String DUMP_INDENT = "  ";

    private static void addParamDump(StringBuilder sb, String key, String value) {
        sb.append(String.format("%-33s", key));
        sb.append(value);
        if (value == null || !value.endsWith(NEWLINE)) {
            sb.append(NEWLINE);
        }
    }

    private static void addParamDump(StringBuilder sb, String key, String value, int indent) {
        String key2 = "";
        for (int i = 0; i < indent; i++) {
            key2 += DUMP_INDENT;
        }
        key2 += key;
        addParamDump(sb, key2, value);
    }

    private static void addParamDump(StringBuilder sb, String key, int value, int indent) {
        addParamDump(sb, key, Integer.toString(value), indent);
    }

    private static void addParamDump(StringBuilder sb, String key, long value, int indent) {
        addParamDump(sb, key, Long.toString(value), indent);
    }

    private static void addParamDumpMulti(StringBuilder sb, String key, String value, int indent) {
        if (value != null && !value.equals("null")) {
            value = NEWLINE + value;
        }
        addParamDump(sb, key, value, indent);
    }

    public static String addTab(String text, Object o, boolean bRecv) {
        String s = NEWLINE + "\t";
        if (o != null) {
            String name;
            if (o instanceof String) {
                name = o.toString();
            } else {
                name = o.getClass().getSimpleName();
            }
            String t;
            if (bRecv) {
                t = "V2:" + name + " received";
            } else {
                t = "try sending V2:" + name;
            }
            s += "[" + t + "]" + NEWLINE + "\t";
        }
        s += text.replace(NEWLINE, NEWLINE + "\t");
        return s;
    }

    // /////////////////////////////////////////////////////////////////////////

    static String toObjString(Object o) {
        if (o != null) {
            return o.toString();
        } else {
            return "null";
        }
    }

    static String toString(Boolean value) {
        if (value != null) {
            return value.toString();
        } else {
            return "null";
        }
    }

    static String toString(BigInteger value) {
        if (value != null) {
            return value.toString();
        } else {
            return "null";
        }
    }

    static String toString(Integer value) {
        if (value == null) {
            return "null";
        } else {
            return value.toString();
        }
    }

    static String toString(Long value) {
        if (value == null) {
            return "null";
        } else {
            return value.toString();
        }
    }

    private static final int LOCAL_TZ_OFFSET = Calendar.getInstance().getTimeZone()
            .getOffset(System.currentTimeMillis());

    private static String toStringCalendar(Calendar cal) {
        // NOTE: %tz makes "+0900" etc. missing ":"
        String s = String.format(Locale.US, "%1$tFT%1$tT%1$tz", cal);
        return s.substring(0, s.length() - 2) + ":" + s.substring(s.length() - 2);
    }

    static String toString(Calendar cal) {
        if (cal == null) {
            return "null";
        } else {
            int tzOff = cal.getTimeZone().getOffset(System.currentTimeMillis());
            if (tzOff != LOCAL_TZ_OFFSET) {
                Calendar local = Calendar.getInstance();
                local.setTimeInMillis(cal.getTimeInMillis());
                return toStringCalendar(cal) + " (" + toStringCalendar(local) + ")";
            } else {
                return toStringCalendar(cal);
            }
        }
    }

    // /////////////////////////////////////////////////////////////////////////

    static String toString(AttributeType attr, int indent) {
        if (attr == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "attributeValue", attr.getAttributeValue().toString(), indent);
        addParamDump(sb, "name", attr.getName(), indent);
        addParamDump(sb, "nameFormat", attr.getNameFormat(), indent);
        addParamDump(sb, "friendlyName", attr.getFriendlyName(), indent);
        addParamDump(sb, "otherAttributes", attr.getOtherAttributes().toString(), indent);
        return sb.toString();
    }

    static String toString(SessionSecurityAttrType attr, int indent) {
        if (attr == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "type", attr.getType(), indent);
        addParamDump(sb, "name", attr.getName(), indent);
        return sb.toString();
    }

    static String toString(List<SessionSecurityAttrType> list, int indent) {
        if (list == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (SessionSecurityAttrType attr : list) {
            addParamDumpMulti(sb, "attr[" + i + "]", toString(attr, indent + 1), indent);
            i++;
        }

        return sb.toString();
    }

    static String toString(AttributeStatementType stat, int indent) {
        if (stat == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (Object o : stat.getAttributeOrEncryptedAttribute()) {
            if (o instanceof AttributeType) {
                addParamDumpMulti(sb, "attr[" + i + "]", toString((AttributeType) o, indent + 1),
                        indent);
            } else {
                addParamDump(sb, "attr[" + i + "]", o.toString(), indent);
            }
            i++;
        }

        return sb.toString();
    }

    static String toString(CommonHeaderType header, int indent) {
        if (header == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "protocolVersion", header.getProtocolVersion(), indent);
        addParamDump(sb, "correlationId", header.getCorrelationId(), indent);
        addParamDump(sb, "requesterNSA", header.getRequesterNSA(), indent);
        addParamDump(sb, "providerNSA", header.getProviderNSA(), indent);
        addParamDump(sb, "replyTo", header.getReplyTo(), indent);
        addParamDumpMulti(sb, "sessionSecurityAttr",
                toString(header.getSessionSecurityAttr(), indent + 1), indent);
        addParamDump(sb, "any", header.getAny().toString(), indent);
        addParamDump(sb, "otherAttributes", header.getOtherAttributes().toString(), indent);
        return sb.toString();
    }

    static String toString(ScheduleType sched, int indent) {
        if (sched == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "startTime", toString(sched.getStartTime()), indent);
        addParamDump(sb, "endTime", toString(sched.getEndTime()), indent);
        return sb.toString();
    }

    static String toString(DirectionalityType dir) {
        if (dir != null) {
            return dir.name();
        } else {
            return "null";
        }
    }

    static String toString(TypeValuePairType pair, int indent) {
        if (pair == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "namespace", pair.getNamespace(), indent);
        addParamDump(sb, "type", pair.getType(), indent);
        addParamDump(sb, "value", pair.getValue().toString(), indent);
        addParamDump(sb, "any", pair.getAny().toString(), indent);
        addParamDump(sb, "otherAttrs", pair.getOtherAttributes().toString(), indent);
        return sb.toString();
    }

    static String toString(TypeValuePairListType list, int indent) {
        if (list == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (TypeValuePairType pair : list.getAttribute()) {
            addParamDumpMulti(sb, "attr[" + i + "]", toString(pair, indent + 1), indent);
            i++;
        }
        return sb.toString();
    }

    public static String toString(TypeValuePairListType list) {
        return toString(list, 0);
    }

    static String toString(OrderedStpType ostp, int indent) {
        if (ostp == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "stp", ostp.getStp(), indent);
        addParamDump(sb, "order", ostp.getOrder(), indent);
        return sb.toString();
    }

    static String toString(StpListType list, int indent) {
        if (list == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (OrderedStpType ostp : list.getOrderedSTP()) {
            addParamDumpMulti(sb, "ostp[" + i + "]", toString(ostp, indent + 1), indent);
            i++;
        }
        return sb.toString();
    }

    static String toString(Map<QName, String> otherAttributes, int indent) {
        if (otherAttributes == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        for (Entry<QName, String> e : otherAttributes.entrySet()) {
            addParamDump(sb, e.getKey().toString(), e.getValue(), indent);
        }
        return sb.toString();
    }

    static String toString(P2PServiceBaseType p2p, int indent) {
        if (p2p == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "capacity", toString(p2p.getCapacity()), indent);
        addParamDump(sb, "directionality", toObjString(p2p.getDirectionality()), indent);
        addParamDump(sb, "symmetricPath", toString(p2p.isSymmetricPath()), indent);
        addParamDump(sb, "sourceSTP", p2p.getSourceSTP(), indent);
        addParamDumpMulti(sb, "ero", toString(p2p.getEro(), indent + 1), indent);
        addParamDump(sb, "destSTP", p2p.getDestSTP(), indent);
        return sb.toString();
    }

    static String toString(ODUType odu, int indent) {
        if (odu == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "sourceSTP", odu.getSourceSTP(), indent);
        addParamDump(sb, "destSTP", odu.getDestSTP(), indent);
        addParamDump(sb, "sourceTsId", odu.getSourceTsId(), indent);
        addParamDump(sb, "destTsId", odu.getDestTsId(), indent);
        addParamDump(sb, "tsWidth", odu.getTsWidth(), indent);
        addParamDumpMulti(sb, "ero", toString(odu.getEro(), indent + 1), indent);
        addParamDumpMulti(sb, "constraints", toString(odu.getConstraints(), indent + 1), indent);
        addParamDump(sb, "pathType", toObjString(odu.getPathType()), indent);
        addParamDump(sb, "pathOrder", toString(odu.getPathOrder()), indent);
        return sb.toString();
    }

    static String toString(LambdaType lambda, int indent) {
        if (lambda == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "sourceSTP", lambda.getSourceSTP(), indent);
        addParamDump(sb, "destSTP", lambda.getDestSTP(), indent);
        addParamDump(sb, "secondarySourceSTP", lambda.getSecondarySourceSTP(), indent);
        addParamDump(sb, "secondaryDestSTP", lambda.getSecondaryDestSTP(), indent);
        addParamDump(sb, "sourceLambdaId", lambda.getSourceLambdaId(), indent);
        addParamDump(sb, "destLambdaId", lambda.getDestLambdaId(), indent);
        addParamDump(sb, "lambdaWidth", lambda.getLambdaWidth(), indent);
        addParamDumpMulti(sb, "ero", toString(lambda.getEro(), indent + 1), indent);
        addParamDump(sb, "isProtection", toString(lambda.isIsProtection()), indent);
        addParamDump(sb, "protectionSourceSTP", lambda.getProtectionSourceSTP(), indent);
        addParamDump(sb, "protectionDestSTP", lambda.getProtectionDestSTP(), indent);
        addParamDumpMulti(sb, "primary", toString(lambda.getPrimary(), indent + 1), indent);
        addParamDumpMulti(sb, "secondary", toString(lambda.getSecondary(), indent + 1), indent);
        addParamDumpMulti(sb, "constraints", toString(lambda.getConstraints(), indent + 1), indent);
        addParamDump(sb, "pathType", toObjString(lambda.getPathType()), indent);
        addParamDump(sb, "pathOrder", toString(lambda.getPathOrder()), indent);
        return sb.toString();
    }

    static String toString(TransferType transfer, int indent) {
        if (transfer == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "sourceSTP", transfer.getSourceSTP(), indent);
        addParamDump(sb, "destSTP", transfer.getDestSTP(), indent);
        addParamDump(sb, "sourceIPAddress", transfer.getSourceIPAddress(), indent);
        addParamDump(sb, "destIPAddress", transfer.getDestIPAddress(), indent);
        addParamDump(sb, "capacity", toString(transfer.getCapacity()), indent);
        addParamDump(sb, "contentId", transfer.getContentId(), indent);
        addParamDump(sb, "service", toObjString(transfer.getService()), indent);
        addParamDump(sb, "role", toObjString(transfer.getRole()), indent);
        addParamDump(sb, "cacheEndTime", toString(transfer.getCacheEndTime()), indent);
        return sb.toString();
    }

    static String toStringCriteriaAny(List<Object> any, int indent) {
        if (any == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (Object o : any) {
            if (o instanceof JAXBElement<?>) {
                Object ele = ((JAXBElement<?>) o).getValue();
                if (ele instanceof P2PServiceBaseType) {
                    addParamDumpMulti(sb, "p2ps[" + i + "]",
                            toString((P2PServiceBaseType) ele, indent + 1), indent);
                } else if (ele instanceof ODUType) {
                    addParamDumpMulti(sb, "odu[" + i + "]", toString((ODUType) ele, indent + 1),
                            indent);
                } else if (ele instanceof LambdaType) {
                    addParamDumpMulti(sb, "lambda[" + i + "]",
                            toString((LambdaType) ele, indent + 1), indent);
                } else if (ele instanceof TransferType) {
                    addParamDumpMulti(sb, "transfer[" + i + "]",
                            toString((TransferType) ele, indent + 1), indent);
                } else if (ele instanceof Integer) {
                    addParamDump(sb, "int[" + i + "]", toString((Integer) ele), indent);
                } else if (ele instanceof Long) {
                    addParamDump(sb, "long[" + i + "]", toString((Long) ele), indent);
                } else {
                    addParamDump(sb, "jaxbany[" + i + "]", o.toString(), indent);
                }
            } else {
                addParamDump(sb, "any[" + i + "]", o.toString(), indent);
            }
            i++;
        }
        return sb.toString();
    }

    static String toString(ReservationRequestCriteriaType criteria, int indent) {
        if (criteria == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "schedule", toString(criteria.getSchedule(), indent + 1), indent);
        addParamDump(sb, "serviceType", criteria.getServiceType(), indent);
        addParamDumpMulti(sb, "any", toStringCriteriaAny(criteria.getAny(), indent + 1), indent);
        addParamDump(sb, "version", toString(criteria.getVersion()), indent);
        addParamDumpMulti(sb, "otherAttributes",
                toString(criteria.getOtherAttributes(), indent + 1), indent);
        return sb.toString();
    }

    public static String toString(ReservationRequestCriteriaType criteria) {
        return toString(criteria, 0);
    }

    public static String toString(CommonHeaderType header, String globalReservationId,
            String description, String connectionId, ReservationRequestCriteriaType criteria) {
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "header", toString(header, 1), 0);
        addParamDump(sb, "globalReservationId", globalReservationId, 0);
        addParamDump(sb, "description", description, 0);
        addParamDump(sb, "connectionId", connectionId, 0);
        addParamDumpMulti(sb, "criteria", toString(criteria, 1), 0);
        return sb.toString();
    }

    public static String toString(CommonHeaderType header, String globalReservationId,
            String description, Holder<String> connectionId, ReservationRequestCriteriaType criteria) {
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "header", toString(header, 1), 0);
        addParamDump(sb, "globalReservationId", globalReservationId, 0);
        addParamDump(sb, "description", description, 0);
        if (connectionId != null) {
            addParamDump(sb, "connectionId", connectionId.value, 0);
        } else {
            addParamDump(sb, "connectionId", "null", 0);
        }
        addParamDumpMulti(sb, "criteria", toString(criteria, 1), 0);
        return sb.toString();
    }

    // /////////////////////////////////////////////////////////////////////////

    static String toString(ReservationConfirmCriteriaType criteria, int indent) {
        if (criteria == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "schedule", toString(criteria.getSchedule(), indent + 1), indent);
        addParamDump(sb, "serviceType", criteria.getServiceType(), indent);
        addParamDumpMulti(sb, "any", toStringCriteriaAny(criteria.getAny(), indent + 1), indent);
        addParamDump(sb, "version", toString(criteria.getVersion()), indent);
        addParamDumpMulti(sb, "serviceAttributes",
                toString(criteria.getOtherAttributes(), indent + 1), indent);
        return sb.toString();
    }

    public static String toString(ReservationConfirmCriteriaType criteria) {
        return toString(criteria, 0);
    }

    static String toString(ReserveConfirmedType reserveConfirmed, int indent) {
        if (reserveConfirmed == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "globalReservationId", reserveConfirmed.getGlobalReservationId(), indent);
        addParamDump(sb, "description", reserveConfirmed.getDescription(), indent);
        addParamDump(sb, "connectionId", reserveConfirmed.getConnectionId(), indent);
        addParamDumpMulti(sb, "criteria", toString(reserveConfirmed.getCriteria(), indent + 1),
                indent);
        return sb.toString();
    }

    public static String toString(CommonHeaderType header, ReserveConfirmedType reserveConfirmed) {
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "header", toString(header, 1), 0);
        addParamDumpMulti(sb, "confirmed", toString(reserveConfirmed, 1), 0);
        return sb.toString();
    }

    public static String toString(CommonHeaderType header, String connectionId,
            long notificationId, Calendar timeStamp, int timeoutValue,
            String originatingConnectionId, String originatingNSA) {
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "header", toString(header, 1), 0);
        addParamDump(sb, "connectionId", connectionId, 0);
        addParamDump(sb, "notificationId", notificationId, 0);
        addParamDump(sb, "timeStamp", toString(timeStamp), 0);
        addParamDump(sb, "timeoutValue", Integer.toString(timeoutValue), 0);
        addParamDump(sb, "originatingConnectionId", originatingConnectionId, 0);
        addParamDump(sb, "originatingNSA", originatingNSA, 0);
        return sb.toString();
    }

    public static String toString(CommonHeaderType header, String connectionId,
            long notificationId, Calendar timeStamp, EventEnumType event,
            String originatingConnectionId, String originatingNSA,
            TypeValuePairListType additionalInfo, ServiceExceptionType serviceException) {
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "header", toString(header, 1), 0);
        addParamDump(sb, "connectionId", connectionId, 0);
        addParamDump(sb, "notificationId", notificationId, 0);
        addParamDump(sb, "timeStamp", toString(timeStamp), 0);
        addParamDump(sb, "originatingConnectionId", originatingConnectionId, 0);
        addParamDump(sb, "originatingNSA", originatingNSA, 0);
        addParamDumpMulti(sb, "additionalInfo", toString(additionalInfo, 1), 0);
        addParamDumpMulti(sb, "serviceException", toString(serviceException, 1), 0);
        return sb.toString();
    }

    // /////////////////////////////////////////////////////////////////////////

    public static String toString(CommonHeaderType header, String connectionId) {
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "header", toString(header, 1), 0);
        addParamDump(sb, "connectionId", connectionId, 0);
        return sb.toString();
    }

    public static String toString(CommonHeaderType header, String globalReservationId,
            String connectionId) {
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "header", toString(header, 1), 0);
        addParamDump(sb, "globalReservationId", globalReservationId, 0);
        addParamDump(sb, "connectionId", connectionId, 0);
        return sb.toString();
    }

    public static String toString(CommonHeaderType header, String globalReservationId,
            String connectionId, Exception e) {
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "header", toString(header, 1), 0);
        addParamDump(sb, "globalReservationId", globalReservationId, 0);
        addParamDump(sb, "connectionId", connectionId, 0);
        return sb.toString();
    }

    // /////////////////////////////////////////////////////////////////////////

    static String toString(DataPlaneStatusType state, int indent) {
        if (state == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "active", Boolean.toString(state.isActive()), indent);
        addParamDump(sb, "version", Integer.toString(state.getVersion()), indent);
        addParamDump(sb, "versionConsistent", Boolean.toString(state.isVersionConsistent()), indent);
        return sb.toString();
    }

    public static String toString(DataPlaneStatusType state) {
        return toString(state, 0);
    }

    public static String toString(ConnectionStatesType connectionStates) {
        return toString(connectionStates, 0);
    }

    static String toString(ConnectionStatesType connectionStates, int indent) {
        if (connectionStates == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "reservationState", toObjString(connectionStates.getReservationState()),
                indent);
        addParamDump(sb, "provisionState", toObjString(connectionStates.getProvisionState()),
                indent);
        addParamDump(sb, "lifecycleState", toObjString(connectionStates.getLifecycleState()),
                indent);
        addParamDumpMulti(sb, "dataPlaneStatus",
                toString(connectionStates.getDataPlaneStatus(), indent + 1), indent);
        return sb.toString();
    }

    public static String toStringSimple(ConnectionStatesType connectionStates) {
        if (connectionStates != null) {
            DataPlaneStatusType ds = connectionStates.getDataPlaneStatus();
            return String.format("rsv=%s, prov=%s, life=%s, isAct=%s, ver=%d, isVCons=%s",
                    toObjString(connectionStates.getReservationState().value()),
                    toObjString(connectionStates.getProvisionState().value()),
                    toObjString(connectionStates.getLifecycleState().value()),
                    Boolean.toString(ds.isActive()), ds.getVersion(),
                    Boolean.toString(ds.isVersionConsistent()));
        } else {
            return "null";
        }
    }

    static String toString(VariablesType variables, int indent) {
        if (variables == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (TypeValuePairType pair : variables.getVariable()) {
            addParamDumpMulti(sb, "pair[" + i + "]", toString(pair, indent + 1), indent);
            i++;
        }
        return sb.toString();
    }

    static String toChildExString(List<ServiceExceptionType> childException, int indent) {
        if (childException == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (ServiceExceptionType ex : childException) {
            addParamDumpMulti(sb, "exception[" + i + "]", toString(ex, indent + 1), indent);
            i++;
        }
        return sb.toString();
    }

    static String toString(ServiceExceptionType ex, int indent) {
        if (ex == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "nsaId", ex.getNsaId(), indent);
        addParamDump(sb, "connectionId", ex.getConnectionId(), indent);
        addParamDump(sb, "serviceType", ex.getServiceType(), indent);
        addParamDump(sb, "errorId", ex.getErrorId(), indent);
        addParamDump(sb, "text", ex.getText(), indent);
        addParamDumpMulti(sb, "variables", toString(ex.getVariables(), indent + 1), indent);
        addParamDumpMulti(sb, "childException",
                toChildExString(ex.getChildException(), indent + 1), indent);
        return sb.toString();
    }

    public static String toString(ServiceExceptionType ex) {
        return toString(ex, 0);
    }

    public static String toString(ServiceException ex) {
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "message", ex.getMessage(), 0);
        addParamDump(sb, "localMessage", ex.getLocalizedMessage(), 0);
        addParamDumpMulti(sb, "serviceExceptionType", toString(ex.getFaultInfo(), 1), 0);
        return sb.toString();
    }

    public static String toString(CommonHeaderType header, String globalReservationId,
            String connectionId, ConnectionStatesType connectionStates,
            ServiceExceptionType serviceException) {
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "header", toString(header, 1), 0);
        addParamDump(sb, "globalReservationId", globalReservationId, 0);
        addParamDump(sb, "connectionId", connectionId, 0);
        addParamDumpMulti(sb, "connectionStates", toString(connectionStates, 1), 0);
        addParamDumpMulti(sb, "serviceException", toString(serviceException, 1), 0);
        return sb.toString();
    }

    public static String toString(CommonHeaderType header, EventEnumType event,
            String connectionId, ConnectionStatesType connectionStates, Calendar timeStamp,
            TypeValuePairListType additionalInfo) {
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "header", toString(header, 1), 0);
        addParamDump(sb, "event", toObjString(event), 0);
        addParamDump(sb, "connectionId", connectionId, 0);
        addParamDumpMulti(sb, "connectionStates", toString(connectionStates, 1), 0);
        addParamDump(sb, "timeStamp", toString(timeStamp), 0);
        addParamDumpMulti(sb, "additionalInfo", toString(additionalInfo, 1), 0);
        return sb.toString();
    }

    // /////////////////////////////////////////////////////////////////////////

    static String toString(QueryType filter, int indent) {
        if (filter == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (String connId : filter.getConnectionId()) {
            addParamDump(sb, "connId[" + i + "]", connId, indent);
            i++;
        }
        i = 0;
        for (String globalId : filter.getGlobalReservationId()) {
            addParamDump(sb, "globalId[" + i + "]", globalId, indent);
            i++;
        }
        return sb.toString();
    }

    static String toString(ChildSummaryType child, int indent) {
        if (child == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "connectionId", child.getConnectionId(), indent);
        addParamDump(sb, "providerNSA", child.getProviderNSA(), indent);
        addParamDump(sb, "serviceType", child.getServiceType(), indent);
        addParamDumpMulti(sb, "any", toStringCriteriaAny(child.getAny(), indent + 1), indent);
        addParamDump(sb, "order", child.getOrder(), indent);
        addParamDumpMulti(sb, "otherAttributes", toString(child.getOtherAttributes(), indent + 1),
                indent);
        return sb.toString();
    }

    static String toString(ChildSummaryListType summary, int indent) {
        if (summary == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (ChildSummaryType child : summary.getChild()) {
            addParamDumpMulti(sb, "child[" + i + "]", toString(child, indent + 1), indent);
            i++;
        }
        return sb.toString();
    }

    static String toString(QuerySummaryResultCriteriaType criteria, int indent) {
        if (criteria == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "schedule", toString(criteria.getSchedule(), indent + 1), indent);
        addParamDump(sb, "serviceType", criteria.getServiceType(), indent);
        addParamDumpMulti(sb, "children", toString(criteria.getChildren(), indent + 1), indent);
        addParamDumpMulti(sb, "any", toStringCriteriaAny(criteria.getAny(), indent + 1), indent);
        addParamDump(sb, "version", criteria.getVersion(), indent);
        addParamDumpMulti(sb, "otherAttributes",
                toString(criteria.getOtherAttributes(), indent + 1), indent);
        return sb.toString();
    }

    static String toStringQuerySummaryResultCriteria(List<QuerySummaryResultCriteriaType> critList,
            int indent) {
        if (critList == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (QuerySummaryResultCriteriaType crit : critList) {
            addParamDumpMulti(sb, "crit[" + i + "]", toString(crit, indent + 1), indent);
            i++;
        }
        return sb.toString();
    }

    public static String toString(QuerySummaryResultType summary) {
        return toString(summary, 0);
    }

    static String toString(QuerySummaryResultType summary, int indent) {
        if (summary == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "connectionId", summary.getConnectionId(), indent);
        addParamDump(sb, "globalReservationId", summary.getGlobalReservationId(), indent);
        addParamDump(sb, "description", summary.getDescription(), indent);
        addParamDumpMulti(sb, "criteria",
                toStringQuerySummaryResultCriteria(summary.getCriteria(), indent + 1), indent);
        addParamDump(sb, "requesterNSA", summary.getRequesterNSA(), indent);
        addParamDumpMulti(sb, "connectionStates",
                toString(summary.getConnectionStates(), indent + 1), indent);
        addParamDump(sb, "notificationId", toString(summary.getNotificationId()), indent);
        return sb.toString();
    }

    public static String toStringQuerySummayList(CommonHeaderType header,
            List<QuerySummaryResultType> querySummaryResultType) {
        StringBuilder sb = new StringBuilder();
        if (header != null) {
            addParamDumpMulti(sb, "header", toString(header, 1), 0);
        }
        int i = 0;
        for (QuerySummaryResultType summary : querySummaryResultType) {
            addParamDumpMulti(sb, "summary[" + i + "]", toString(summary, 1), 0);
            i++;
        }
        return sb.toString();
    }

    public static String toStringQuerySummayList(List<QuerySummaryResultType> querySummaryResultType) {
        return toStringQuerySummayList(null, querySummaryResultType);
    }

    public static String toString(CommonHeaderType header, ServiceExceptionType serviceException) {
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "header", toString(header, 1), 0);
        addParamDumpMulti(sb, "serviceException", toString(serviceException, 1), 0);
        return sb.toString();
    }

    public static String toString(CommonHeaderType header, String connectionId,
            long notificationId, Calendar timeStamp, String correlationId) {
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "header", toString(header, 1), 0);
        addParamDump(sb, "connectionId", connectionId, 0);
        addParamDump(sb, "notificationId", notificationId, 0);
        addParamDump(sb, "timeStamp", toString(timeStamp), 0);
        addParamDump(sb, "correlationId", correlationId, 0);
        return sb.toString();
    }

    public static String toString(CommonHeaderType header, String connectionId,
            long notificationId, Calendar timeStamp, DataPlaneStatusType dataPlaneStatus) {
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "header", toString(header, 1), 0);
        addParamDump(sb, "connectionId", connectionId, 0);
        addParamDump(sb, "notificationId", notificationId, 0);
        addParamDump(sb, "timeStamp", toString(timeStamp), 0);
        addParamDumpMulti(sb, "dataPlaneStatus", toString(dataPlaneStatus, 1), 0);
        return sb.toString();
    }

    public static String toString(CommonHeaderType header, String connectionId,
            long notificationId, Calendar timeStamp, EventEnumType event,
            TypeValuePairListType additionalInfo, ServiceExceptionType serviceException) {
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "header", toString(header, 1), 0);
        addParamDump(sb, "connectionId", connectionId, 0);
        addParamDump(sb, "notificationId", notificationId, 0);
        addParamDump(sb, "timeStamp", toString(timeStamp), 0);
        addParamDump(sb, "event", toObjString(event), 0);
        addParamDumpMulti(sb, "additionalInfo", toString(additionalInfo, 1), 0);
        addParamDumpMulti(sb, "serviceException", toString(serviceException, 1), 0);
        return sb.toString();
    }

    static String toStringRecursiveCritList(List<QueryRecursiveResultCriteriaType> criteria,
            int indent) {
        if (criteria == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (QueryRecursiveResultCriteriaType crit : criteria) {
            addParamDumpMulti(sb, "criteria[" + i + "]", toString(crit, indent + 1), indent);
            i++;
        }
        return sb.toString();
    }

    static String toString(ChildRecursiveType child, int indent) {
        if (child == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "connectionId", child.getConnectionId(), indent);
        addParamDump(sb, "providerNSA", child.getProviderNSA(), indent);
        addParamDumpMulti(sb, "connectionStates",
                toString(child.getConnectionStates(), indent + 1), indent);
        addParamDumpMulti(sb, "criteria",
                toStringRecursiveCritList(child.getCriteria(), indent + 1), indent);
        addParamDump(sb, "order", child.getOrder(), indent);
        return sb.toString();
    }

    static String toString(ChildRecursiveListType recursive, int indent) {
        if (recursive == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (ChildRecursiveType child : recursive.getChild()) {
            addParamDumpMulti(sb, "child[" + i + "]", toString(child, indent + 1), indent);
            i++;
        }
        return sb.toString();

    }

    static String toString(QueryRecursiveResultCriteriaType criteria, int indent) {
        if (criteria == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "schedule", toString(criteria.getSchedule(), indent + 1), indent);
        addParamDump(sb, "serviceType", criteria.getServiceType(), indent);
        addParamDumpMulti(sb, "children", toString(criteria.getChildren(), indent + 1), indent);
        addParamDumpMulti(sb, "any", toStringCriteriaAny(criteria.getAny(), indent + 1), indent);
        addParamDump(sb, "version", criteria.getVersion(), indent);
        addParamDumpMulti(sb, "otherAttributes",
                toString(criteria.getOtherAttributes(), indent + 1), indent);
        return sb.toString();
    }

    static String toStringQueryRecursiveResultCriteria(
            List<QueryRecursiveResultCriteriaType> criteria, int indent) {
        if (criteria == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (QueryRecursiveResultCriteriaType crit : criteria) {
            addParamDumpMulti(sb, "criteria[" + i + "]", toString(crit, indent + 1), indent);
            i++;
        }
        return sb.toString();
    }

    static String toString(QueryRecursiveResultType recursive, int indent) {
        if (recursive == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "connectionId", recursive.getConnectionId(), indent);
        addParamDump(sb, "globalReservationId", recursive.getGlobalReservationId(), indent);
        addParamDump(sb, "description", recursive.getDescription(), indent);
        addParamDumpMulti(sb, "criteria",
                toStringQueryRecursiveResultCriteria(recursive.getCriteria(), indent + 1), indent);
        addParamDump(sb, "requesterNSA", recursive.getRequesterNSA(), indent);
        addParamDumpMulti(sb, "connectionStates",
                toString(recursive.getConnectionStates(), indent + 1), indent);
        addParamDump(sb, "notificationId", toString(recursive.getNotificationId()), indent);
        return sb.toString();
    }

    public static String toStringQueryRecursiveList(CommonHeaderType header,
            List<QueryRecursiveResultType> reservation) {
        StringBuilder sb = new StringBuilder();
        if (header != null) {
            addParamDumpMulti(sb, "header", toString(header, 1), 0);
        }
        int i = 0;
        for (QueryRecursiveResultType recursive : reservation) {
            addParamDumpMulti(sb, "recursive[" + i + "]", toString(recursive, 1), 0);
            i++;
        }
        return sb.toString();
    }

    public static String toStringQueryRecursiveList(List<QueryRecursiveResultType> reservation) {
        return toStringQueryRecursiveList(null, reservation);
    }

    public static String toString(CommonHeaderType header, String connectionId,
            ServiceExceptionType serviceException) {
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "header", toString(header, 1), 0);
        addParamDump(sb, "connectionId", connectionId, 0);
        addParamDumpMulti(sb, "serviceException", toString(serviceException, 1), 0);
        return sb.toString();
    }

    public static String toString(CommonHeaderType header, String connectionId,
            ConnectionStatesType connectionStates, ServiceExceptionType serviceException) {
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "header", toString(header, 1), 0);
        addParamDump(sb, "connectionId", connectionId, 0);
        addParamDumpMulti(sb, "connectionStates", toString(connectionStates, 1), 0);
        addParamDumpMulti(sb, "serviceException", toString(serviceException, 1), 0);
        return sb.toString();
    }

    static void toString(StringBuilder sb, NotificationBaseType base, int indent) {
        addParamDump(sb, "connectionId", base.getConnectionId(), indent);
        addParamDump(sb, "notificationId", base.getNotificationId(), indent);
        addParamDump(sb, "timeStamp", toString(base.getTimeStamp()), indent);
    }

    static String toString(NotificationBaseType base, int indent) {
        if (base == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "<class>", base.getClass().getSimpleName(), indent);
        addParamDump(sb, "connectionId", base.getConnectionId(), indent);
        addParamDump(sb, "notificationId", base.getNotificationId(), indent);
        addParamDump(sb, "timeStamp", toString(base.getTimeStamp()), indent);
        return sb.toString();
    }

    static String toString(ErrorEventType event, int indent) {
        if (event == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        toString(sb, event, indent);
        addParamDump(sb, "event", toObjString(event.getEvent()), indent);
        addParamDumpMulti(sb, "additionalInfo", toString(event.getAdditionalInfo(), indent + 1),
                indent);
        addParamDumpMulti(sb, "serviceException",
                toString(event.getServiceException(), indent + 1), indent);
        return sb.toString();
    }

    static String toString(ReserveTimeoutRequestType req, int indent) {
        if (req == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        toString(sb, req, indent);
        addParamDump(sb, "timeoutValue", req.getTimeoutValue(), indent);
        addParamDump(sb, "originatingConnectionId", req.getOriginatingConnectionId(), indent);
        addParamDump(sb, "originatingNSA", req.getOriginatingNSA(), indent);
        return sb.toString();
    }

    static String toString(MessageDeliveryTimeoutRequestType req, int indent) {
        if (req == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        toString(sb, req, indent);
        addParamDump(sb, "correlationId", req.getCorrelationId(), indent);
        return sb.toString();
    }

    static String toString(QueryNotificationConfirmedType confirmed, int indent) {
        if (confirmed == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (NotificationBaseType base : confirmed
                .getErrorEventOrReserveTimeoutOrDataPlaneStateChange()) {
            if (base instanceof ErrorEventType) {
                addParamDumpMulti(sb, "err[" + i + "]",
                        toString((ErrorEventType) base, indent + 1), indent);
            } else if (base instanceof ReserveTimeoutRequestType) {
                addParamDumpMulti(sb, "rsvtimeout[" + i + "]",
                        toString((ReserveTimeoutRequestType) base, indent + 1), indent);
            } else if (base instanceof MessageDeliveryTimeoutRequestType) {
                addParamDumpMulti(sb, "mdltimeout[" + i + "]",
                        toString((MessageDeliveryTimeoutRequestType) base, indent + 1), indent);
            } else {
                addParamDumpMulti(sb, "ntf[" + i + "]", toString(base, indent + 1), indent);
            }
        }
        return sb.toString();
    }

    public static String toString(QueryNotificationConfirmedType confirmed) {
        return toString(confirmed, 0);
    }

    public static String toString(CommonHeaderType header,
            QueryNotificationConfirmedType queryNotificationConfirmed) {
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "header", toString(header, 1), 0);
        addParamDumpMulti(sb, "qryNtfConfirmed", toString(queryNotificationConfirmed, 1), 0);
        return sb.toString();
    }

    public static String toString(CommonHeaderType header, QueryType queryType) {
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "header", toString(header, 1), 0);
        addParamDumpMulti(sb, "queryType", toString(queryType, 1), 0);
        return sb.toString();
    }

    public static String toString(CommonHeaderType header, QuerySummaryConfirmedType summary) {
        return toStringQuerySummayList(header, summary.getReservation());
    }

    public static String toString(QuerySummaryConfirmedType summary) {
        return toStringQuerySummayList(null, summary.getReservation());
    }

    public static String toString(CommonHeaderType header, String connectionId,
            Long startNotificationId, Long endNotificationId) {
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "header", toString(header, 1), 0);
        addParamDump(sb, "connectionId", connectionId, 0);
        addParamDump(sb, "startNotificationId", toString(startNotificationId), 0);
        addParamDump(sb, "endNotificationId", toString(endNotificationId), 0);
        return sb.toString();
    }

    private static String toString(net.glambda.rms.types.StpType stp, int indent) {
        if (stp == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "networkId", stp.getNetworkId(), indent);
        addParamDump(sb, "localId", stp.getLocalId(), indent);
        return sb.toString();
    }

    static String toString(net.glambda.rms.types.OrderedStpType ostp, int indent) {
        if (ostp == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "stp", toString(ostp.getStp(), indent + 1), indent);
        addParamDump(sb, "order", ostp.getOrder(), indent);
        return sb.toString();
    }

    static String toString(net.glambda.rms.types.StpListType ero) {
        if (ero == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (net.glambda.rms.types.OrderedStpType ostp : ero.getOrderedSTP()) {
            addParamDumpMulti(sb, "ostp[" + i + "]", toString(ostp, 1), 0);
            i++;
        }
        return sb.toString();
    }

    static String toString(EthernetCriteria ether, int indent) {
        if (ether == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "capacity", toString(ether.getCapacity()), indent);
        addParamDump(sb, "directionality", toObjString(ether.getDirectionality()), indent);
        addParamDump(sb, "symmetricPath", toString(ether.getSymmetricPath()), indent);
        addParamDumpMulti(sb, "sourceSTP", toString(ether.getSourceSTP(), indent + 1), indent);
        addParamDumpMulti(sb, "destSTP", toString(ether.getDestSTP(), indent + 1), indent);
        addParamDumpMulti(sb, "ero", toString(ether.getEro()), indent);
        addParamDump(sb, "mtu", toString(ether.getMtu()), indent);
        addParamDump(sb, "burstsize", toString(ether.getBurstsize()), indent);
        addParamDump(sb, "sourceVLAN", toString(ether.getSourceVLAN()), indent);
        addParamDump(sb, "destVLAN", toString(ether.getDestVLAN()), indent);
        return sb.toString();
    }

    public static String toString(EthernetCriteria ether) {
        return toString(ether, 0);
    }

    static String toString(ODUCriteria odu, int indent) {
        if (odu == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "sourceSTP", toString(odu.getSourceSTP(), indent + 1), indent);
        addParamDumpMulti(sb, "destSTP", toString(odu.getDestSTP(), indent + 1), indent);
        addParamDump(sb, "superNetworkType", odu.getSuperNetworkType(), indent);
        addParamDump(sb, "pathType", odu.getPathType(), indent);
        addParamDump(sb, "pathOrder", odu.getPathOrder(), indent);
        addParamDump(sb, "sourceIfType", odu.getSourceIfType(), indent);
        addParamDump(sb, "destIfType", odu.getDestIfType(), indent);
        addParamDump(sb, "sourceTsId", odu.getSourceTsId(), indent);
        addParamDump(sb, "destTsId", odu.getDestTsId(), indent);
        addParamDump(sb, "sourceTsWidth", odu.getSourceTsWidth(), indent);
        addParamDump(sb, "destTsWidth", odu.getDestTsWidth(), indent);
        return sb.toString();
    }

    static String toString(LambdaCriteria lambda, int indent) {
        if (lambda == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "sourceSTP", toString(lambda.getSourceSTP(), indent + 1), indent);
        addParamDumpMulti(sb, "destSTP", toString(lambda.getDestSTP(), indent + 1), indent);
        addParamDump(sb, "superNetworkType", lambda.getSuperNetworkType(), indent);
        addParamDump(sb, "isProtection", Boolean.toString(lambda.isProtection()), indent);
        addParamDumpMulti(sb, "secondarySourceSTP",
                toString(lambda.getSecondarySourceSTP(), indent + 1), indent);
        addParamDumpMulti(sb, "secondaryDestSTP",
                toString(lambda.getSecondaryDestSTP(), indent + 1), indent);
        addParamDump(sb, "pathType", lambda.getPathType(), indent);
        addParamDump(sb, "pathOrder", lambda.getPathOrder(), indent);
        addParamDump(sb, "sourceIfType", lambda.getSourceIfType(), indent);
        addParamDump(sb, "destIfType", lambda.getDestIfType(), indent);
        addParamDump(sb, "sourceLambdaId", lambda.getSourceLambdaId(), indent);
        addParamDump(sb, "destLambdaId", lambda.getDestLambdaId(), indent);
        addParamDump(sb, "sourceLambdaWidth", lambda.getSourceLambdaWidth(), indent);
        addParamDump(sb, "destLambdaWidth", lambda.getDestLambdaWidth(), indent);
        return sb.toString();
    }

    static String toString(TransferCriteria transfer, int indent) {
        if (transfer == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "sourceSTP", transfer.getSourceSTP(), indent);
        addParamDump(sb, "destSTP", transfer.getDestSTP(), indent);
        addParamDump(sb, "sourceIPAddress", transfer.getSourceIPAddress(), indent);
        addParamDump(sb, "destIPAddress", transfer.getDestIPAddress(), indent);
        addParamDump(sb, "capacity", toString(transfer.getCapacity()), indent);
        addParamDump(sb, "contentId", transfer.getContentId(), indent);
        addParamDump(sb, "service", toObjString(transfer.getService()), indent);
        addParamDump(sb, "role", toObjString(transfer.getRole()), indent);
        addParamDump(sb, "cacheEndTime", toString(transfer.getCacheEndTime()), indent);
        return sb.toString();
    }

    public static String toString(CriteriaBase criteria) {
        if (criteria == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "startTime", toString(criteria.getStartTime()), 0);
        addParamDump(sb, "endTime", toString(criteria.getEndTime()), 0);
        addParamDump(sb, "version", toString(criteria.getVersion()), 0);
        //
        if (criteria instanceof EthernetCriteria) {
            addParamDumpMulti(sb, "ether", toString((EthernetCriteria) criteria, 1), 0);
        } else if (criteria instanceof ODUCriteria) {
            addParamDumpMulti(sb, "odu", toString((ODUCriteria) criteria, 1), 0);
        } else if (criteria instanceof LambdaCriteria) {
            addParamDumpMulti(sb, "lambda", toString((LambdaCriteria) criteria, 1), 0);
        } else if (criteria instanceof TransferCriteria) {
            addParamDumpMulti(sb, "transfer", toString((TransferCriteria) criteria, 1), 0);
        }
        return sb.toString();
    }

    static String toString(STP stp, int indent) {
        if (stp == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "networkId", stp.networkId, indent);
        addParamDump(sb, "localId", stp.localId, indent);
        addParamDump(sb, "ifType", toObjString(stp.ifType), indent);
        addParamDump(sb, "tsId", stp.tsId, indent);
        addParamDump(sb, "tsWidth", stp.tsWidth, indent);
        addParamDump(sb, "lambdaId", stp.lambdaId, indent);
        addParamDump(sb, "lambdaWidth", stp.lambdaWidth, indent);
        return sb.toString();
    }

    private static String toStringPathFinderSTPList(List<STP> ero, int indent) {
        if (ero == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (STP stp : ero) {
            addParamDumpMulti(sb, "stp[" + i + "]", toString(stp, indent + 1), indent);
            i++;
        }
        return sb.toString();
    }

    private static String toStringPathFinderConstraints(Map<String, Range> constraints, int indent) {
        if (constraints == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (Entry<String, Range> e : constraints.entrySet()) {
            addParamDump(sb, "const[" + i + "]",
                    String.format("%s: [%f - %f]", e.getKey(), e.getValue().min, e.getValue().max),
                    indent);
            i++;
        }
        return sb.toString();
    }

    public static String toString(PathFindingCriteria criteria) {
        if (criteria == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "queryId", criteria.queryId, 0);
        addParamDump(sb, "superNetworkType", toObjString(criteria.superNetworkType), 0);
        addParamDump(sb, "startTime", toString(criteria.startTime), 0);
        addParamDump(sb, "endTime", toString(criteria.endTime), 0);
        addParamDumpMulti(sb, "srcStp", toString(criteria.srcStp, 1), 0);
        addParamDumpMulti(sb, "dstStp", toString(criteria.dstStp, 1), 0);
        addParamDumpMulti(sb, "ero", toStringPathFinderSTPList(criteria.ero, 1), 0);
        addParamDump(sb, "isProtection", toString(criteria.isProtection), 0);
        addParamDumpMulti(sb, "protectionSrcSTP", toString(criteria.protectionSrcSTP, 1), 0);
        addParamDumpMulti(sb, "protectionDstSTP", toString(criteria.protectionDstSTP, 1), 0);
        addParamDumpMulti(sb, "primary", toStringPathFinderSTPList(criteria.primary, 1), 0);
        addParamDumpMulti(sb, "secondary", toStringPathFinderSTPList(criteria.secondary, 1), 0);
        addParamDumpMulti(sb, "constraints",
                toStringPathFinderConstraints(criteria.constraints, 1), 0);
        return sb.toString();
    }

    static String toString(Path path, int indent) {
        if (path == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDumpMulti(sb, "srcStp", toString(path.srcStp, indent + 1), indent);
        addParamDumpMulti(sb, "dstStp", toString(path.dstStp, indent + 1), indent);
        return sb.toString();
    }

    static String toStringPathFinderPathList(List<Path> list, int indent) {
        if (list == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (Path path : list) {
            addParamDumpMulti(sb, "path[" + i + "]", toString(path, indent + 1), indent);
            i++;
        }
        return sb.toString();
    }

    static String toStringPathFinderConstraintsResults(Map<String, List<Float>> map, int indent) {
        if (map == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (Entry<String, List<Float>> e : map.entrySet()) {
            addParamDump(sb, "const[" + i + "]", String.format("%s: %s", e.getKey(), e.getValue()),
                    indent);
            i++;
        }
        return sb.toString();
    }

    public static String toString(PathFindingResult result) {
        if (result == null) {
            return "null";
        }
        StringBuilder sb = new StringBuilder();
        addParamDump(sb, "queryId", result.queryId, 0);
        addParamDumpMulti(sb, "ero", toStringPathFinderPathList(result.ero, 1), 0);
        addParamDumpMulti(sb, "primary", toStringPathFinderPathList(result.primary, 1), 0);
        addParamDumpMulti(sb, "secondary", toStringPathFinderPathList(result.secondary, 1), 0);
        addParamDumpMulti(sb, "constraintResults",
                toStringPathFinderConstraintsResults(result.constraintResults, 1), 0);
        return sb.toString();
    }

}
