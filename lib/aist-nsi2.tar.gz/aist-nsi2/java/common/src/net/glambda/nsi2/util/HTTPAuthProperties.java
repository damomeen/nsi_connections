/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;

import org.apache.commons.logging.Log;

import net.glambda.nsi2.impl.NSIProperties;

public class HTTPAuthProperties {

    private static final NSIProperties nsiProp = NSIProperties.getInstance();
    protected static final Log logger = AbstractLog.getLog(HTTPAuthProperties.class);

    private static final String PROP_DELIM = "\t+";
    private static final String AUTH_BASIC = "basic";
    private static final String AUTH_OAUTH2 = "oauth2";

    public static class BasicAuth {
        private final String username, password;

        BasicAuth(String username, String password) {
            this.username = username;
            this.password = password;
        }

        public String username() {
            return username;
        }

        public String password() {
            return password;
        }
    }

    private final HashMap<String, BasicAuth> basicAuthMap = new HashMap<String, BasicAuth>();
    private final HashMap<String, String> oauthMap = new HashMap<String, String>();

    private static final HTTPAuthProperties instance = new HTTPAuthProperties();

    private HTTPAuthProperties() {
        String propFile = nsiProp.getProperty("nsi.httpauth");
        if (propFile != null) {
            try {
                load(propFile);
            } catch (Exception e) {
                logger.warn(e);
            }
        }
    }

    private void load(String filename) throws Exception {
        InputStream in = new FileInputStream(new File(filename));
        BufferedReader br = new BufferedReader(new InputStreamReader(in));
        String line;
        while ((line = br.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty() || line.startsWith("#")) {
                continue;
            }

            String[] params = line.split(PROP_DELIM);
            switch (params.length) {
            case 4:
                // "host basic username password"
                if (params[1].equalsIgnoreCase(AUTH_BASIC)) {
                    if (oauthMap.containsKey(params[0])) {
                        logger.error("host=" + params[0] + " has " + AUTH_OAUTH2
                                + " setting already");
                    } else {
                        basicAuthMap.put(params[0], new BasicAuth(params[2], params[3]));
                        logger.info("HTTP BASIC Auth: host=" + params[0] + ", user=" + params[2]
                                + ", pass=" + params[3]);
                    }
                } else {
                    logger.warn("invalid auth type: " + params[1] + ", must be " + AUTH_BASIC);
                }
                break;
            case 3:
                // "host oauth2 token"
                if (params[1].equalsIgnoreCase(AUTH_OAUTH2)) {
                    if (basicAuthMap.containsKey(params[0])) {
                        logger.error("host=" + params[0] + " has " + AUTH_BASIC
                                + " setting already");
                    } else {
                        oauthMap.put(params[0], params[2]);
                        logger.info("HTTP OAuth2: host=" + params[0] + ", token=" + params[2]);
                    }
                } else {
                    logger.warn("invalid auth type: " + params[1] + ", must be " + AUTH_OAUTH2);
                }
                break;
            default:
                logger.warn("invalid httpauth line: " + line);
                break;
            }
        }
        br.close();
    }

    public static BasicAuth getHTTPBasicAuth(String host) {
        return instance.basicAuthMap.get(host);
    }

    public static String getOAuth2Token(String host) {
        return instance.oauthMap.get(host);
    }
}
