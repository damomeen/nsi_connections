/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.impl;

import java.util.List;

import javax.xml.ws.Holder;

import net.glambda.nsi2.util.NSIPortManager;
import net.glambda.nsi2.util.NSIUtil;

import org.ogf.schemas.nsi._2013._12.connection._interface.Error;
import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.provider.ConnectionProviderPort;
import org.ogf.schemas.nsi._2013._12.connection.types.GenericAcknowledgmentType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryNotificationConfirmedType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryNotificationType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryResultResponseType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryConfirmedType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType;
import org.ogf.schemas.nsi._2013._12.framework.headers.CommonHeaderType;

public class ProviderPortReconnectAlways implements ConnectionProviderPort {

    private final String uri;
    private CommonHeaderType header;

    private static final NSIPortManager portMgr = NSIPortManager.getInstance();

    public ProviderPortReconnectAlways(String uri) {
        this.uri = uri;
    }

    public void setCommonHeader(CommonHeaderType header) {
        this.header = header;
    }

    @Override
    public void reserve(Holder<String> connectionId, String globalReservationId,
            String description, ReservationRequestCriteriaType criteria) throws ServiceException {
        ConnectionProviderPort port = NSIUtil.getRawProviderPort(uri);
        portMgr.setCommonHeader(port, header);
        port.reserve(connectionId, globalReservationId, description, criteria);
    }

    @Override
    public void reserveCommit(String connectionId) throws ServiceException {
        ConnectionProviderPort port = NSIUtil.getRawProviderPort(uri);
        portMgr.setCommonHeader(port, header);
        port.reserveCommit(connectionId);
    }

    @Override
    public void reserveAbort(String connectionId) throws ServiceException {
        ConnectionProviderPort port = NSIUtil.getRawProviderPort(uri);
        portMgr.setCommonHeader(port, header);
        port.reserveAbort(connectionId);
    }

    @Override
    public void provision(String connectionId) throws ServiceException {
        ConnectionProviderPort port = NSIUtil.getRawProviderPort(uri);
        portMgr.setCommonHeader(port, header);
        port.provision(connectionId);
    }

    @Override
    public void release(String connectionId) throws ServiceException {
        ConnectionProviderPort port = NSIUtil.getRawProviderPort(uri);
        portMgr.setCommonHeader(port, header);
        port.release(connectionId);
    }

    @Override
    public void terminate(String connectionId) throws ServiceException {
        ConnectionProviderPort port = NSIUtil.getRawProviderPort(uri);
        portMgr.setCommonHeader(port, header);
        port.terminate(connectionId);
    }

    @Override
    public GenericAcknowledgmentType querySummary(QueryType querySummary) throws ServiceException {
        ConnectionProviderPort port = NSIUtil.getRawProviderPort(uri);
        portMgr.setCommonHeader(port, header);
        return port.querySummary(querySummary);
    }

    @Override
    public QuerySummaryConfirmedType querySummarySync(QueryType querySummarySync) throws Error {
        ConnectionProviderPort port = NSIUtil.getRawProviderPort(uri);
        portMgr.setCommonHeader(port, header);
        return port.querySummarySync(querySummarySync);
    }

    @Override
    public GenericAcknowledgmentType queryRecursive(QueryType queryRecursive)
            throws ServiceException {
        ConnectionProviderPort port = NSIUtil.getRawProviderPort(uri);
        portMgr.setCommonHeader(port, header);
        return port.queryRecursive(queryRecursive);
    }

    @Override
    public List<QueryResultResponseType> queryResultSync(String connectionId, Long startResultId,
            Long endResultId) throws Error {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void queryNotification(String connectionId, Long startNotificationId,
            Long endNotificationId) throws ServiceException {
        ConnectionProviderPort port = NSIUtil.getRawProviderPort(uri);
        portMgr.setCommonHeader(port, header);
        port.queryNotification(connectionId, startNotificationId, endNotificationId);
    }

    @Override
    public QueryNotificationConfirmedType queryNotificationSync(
            QueryNotificationType queryNotificationSync) throws Error {
        ConnectionProviderPort port = NSIUtil.getRawProviderPort(uri);
        portMgr.setCommonHeader(port, header);
        return port.queryNotificationSync(queryNotificationSync);
    }

    @Override
    public void queryResult(String connectionId, Long startResultId, Long endResultId)
            throws ServiceException {
        // TODO Auto-generated method stub

    }

}
