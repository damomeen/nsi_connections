/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.impl;

import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType;
import org.ogf.schemas.nsi._2013._12.services.point2point.P2PServiceBaseType;

import net.glambda.nsi2.util.ErrorID;
import net.glambda.nsi2.util.NSIExceptionUtil;
import net.glambda.nsi2.util.TypesBuilder;
import net.glambda.rms.NSI2ResourceManagerBase;

// @org.apache.cxf.interceptor.OutInterceptors (interceptors = {"net.glambda.nsi2.impl.FixSoapHeaderInterceptor" })
public class ResourceManagerBase extends SampleProvider {

    public ResourceManagerBase(NSI2ResourceManagerBase resourceManager) {
        super(new ResourceManagerHandler(resourceManager));
    }

    private void checkSTP(String stp, String name) throws ServiceException {
        if (stp == null) {
            throw NSIExceptionUtil.makeServiceException(ErrorID.MISSING_PARAMETER, null, name);
        }
    }

    private void checkPath(P2PServiceBaseType p2p) throws ServiceException {
        if (p2p == null) {
            return;
        }
        String src = p2p.getSourceSTP();
        checkSTP(src, "P2PServiceBaseType.SourceSTP");
        String dst = p2p.getDestSTP();
        checkSTP(dst, "P2PServiceBaseType.DestinationSTP");
        if (src.equals(dst)) {
            throw NSIExceptionUtil.makeServiceException(ErrorID.UNSUPPORTED_PARAMETER, null,
                    "same StpId: src=" + src + ", dst=" + dst);
        }
    }

    protected void checkReservationCriteria(ReservationRequestCriteriaType criteria, boolean bNew)
            throws ServiceException {
        super.checkReservationCriteria(criteria, "");
        if (bNew) {
            Object o = TypesBuilder.getObject(criteria.getAny());
            if (o instanceof P2PServiceBaseType) {
                checkPath((P2PServiceBaseType) o);
            }
        }
    }
}
