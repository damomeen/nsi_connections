/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.impl;

import java.util.Calendar;
import java.util.List;

import net.glambda.nsi2.impl.StateMachineManager;

import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.types.ConnectionStatesType;
import org.ogf.schemas.nsi._2013._12.connection.types.DataPlaneStatusType;
import org.ogf.schemas.nsi._2013._12.connection.types.EventEnumType;
import org.ogf.schemas.nsi._2013._12.connection.types.GenericAcknowledgmentType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryNotificationConfirmedType;
import org.ogf.schemas.nsi._2013._12.connection.types.QueryRecursiveResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationConfirmCriteriaType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType;
import org.ogf.schemas.nsi._2013._12.framework.types.ServiceExceptionType;
import org.ogf.schemas.nsi._2013._12.framework.types.TypeValuePairListType;

public interface ProviderHandler {

    public void setStatusMachineManager(StateMachineManager smMgr);

    public StateMachineManager getStatusMachineManager();

    // /////////////////////////////////////////////////////////////////////////

    public void reserve(ProviderArgument arg, String connectionId, String globalReservationId,
            String description, ReservationRequestCriteriaType criteria) throws ServiceException;

    public void modify(ProviderArgument arg, String connectionId, String globalReservationId,
            String description, ReservationRequestCriteriaType criteria) throws ServiceException;

    public ReservationConfirmCriteriaType sendReserveConfirmed(ProviderArgument arg,
            String connectionId, String globalReservationId, String description,
            ReservationRequestCriteriaType criteria, int version);

    public void sendReserveFailed(ProviderArgument arg, String connectionId,
            String globalReservationId, String description,
            ReservationRequestCriteriaType criteria, Exception e);

    // /////////////////////////////////////////////////////////////////////////

    public void reserveCommit(ProviderArgument arg, String connectionId) throws ServiceException;

    public void sendReserveCommitConfirmed(ProviderArgument arg, String connectionId);

    public void sendReserveCommitFailed(ProviderArgument arg, String connectionId,
            ConnectionStatesType connectionStates, Exception e);

    // /////////////////////////////////////////////////////////////////////////

    public void reserveAbort(ProviderArgument arg, String connectionId) throws ServiceException;

    public void sendReserveAbortConfirmed(ProviderArgument arg, String connectionId);

    public void sendReserveTimeout(ProviderArgument arg, String connectionId, long notificationId,
            Calendar timeStamp, int timeoutValue, String originatingConnectionId,
            String originatingNSA);

    // /////////////////////////////////////////////////////////////////////////

    public void provision(ProviderArgument arg, String connectionId) throws ServiceException;

    public void sendProvisionConfirmed(ProviderArgument arg, String connectionId);

    // /////////////////////////////////////////////////////////////////////////

    public void release(ProviderArgument arg, String connectionId) throws ServiceException;

    public void sendReleaseConfirmed(ProviderArgument arg, String connectionId);

    // /////////////////////////////////////////////////////////////////////////

    public void terminate(ProviderArgument arg, String connectionId) throws ServiceException;

    public void sendTerminateConfirmed(ProviderArgument arg, String connectionId);

    // /////////////////////////////////////////////////////////////////////////

    public QuerySummaryResultType querySummary(ProviderArgument arg, StateMachineManager smMgr,
            String connectionId) throws ServiceException;

    public QueryRecursiveResultType queryRecursive(ProviderArgument arg, StateMachineManager smMgr,
            String connectionId) throws ServiceException;

    public void sendQuerySummaryConfirmed(ProviderArgument arg,
            List<QuerySummaryResultType> reservation);

    public void sendQuerySummaryFailed(ProviderArgument arg, Exception e);

    public void sendQueryRecursiveConfirmed(ProviderArgument arg,
            List<QueryRecursiveResultType> reservation);

    public void sendQueryRecursiveFailed(ProviderArgument arg, Exception e);

    // /////////////////////////////////////////////////////////////////////////

    public GenericAcknowledgmentType sendQueryNotificationConfirmed(ProviderArgument arg,
            QueryNotificationConfirmedType queryNotificationConfirmed);

    public void sendQueryNotificationFailed(ProviderArgument arg,
            ServiceExceptionType serviceException);

    public void sendMessageDeliveryTimeout(ProviderArgument arg, String connectionId,
            int notificationId, Calendar timeStamp, String correlationId);

    public void sendDataPlaneStateChange(ProviderArgument arg, String connectionId,
            int notificationId, Calendar timeStamp, DataPlaneStatusType dataPlaneStatus);

    public void sendErrorEvent(ProviderArgument arg, String connectionId, long notificationId,
            Calendar timeStamp, EventEnumType event, String originatingConnectionId,
            String originatingNSA, TypeValuePairListType additionalInfo, Exception e);

}
