/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.util;

import java.io.PrintWriter;
import java.io.StringWriter;

import net.glambda.nsi2.impl.NSIProperties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class AbstractLog implements Log {

    private final Log log;

    private static final NSIProperties nsiProp = NSIProperties.getInstance();
    private static boolean USE_ABSTRACT_EX = !"false".equals(nsiProp
            .getProperty(NSIProperties.PROP_ABSTRACT_EX));

    private static final String NEWLINE = System.getProperty("line.separator");

    public static String abstractTrace(Throwable e) {
        if (e == null) {
            return "";
        }
        StringWriter s = new StringWriter();
        PrintWriter w = new PrintWriter(s);
        e.printStackTrace(w);
        w.flush();
        StringBuffer sb = new StringBuffer();
        int count = 0;
        for (String line : s.toString().split(NEWLINE)) {
            if (line.isEmpty()) {
                continue;
            }
            boolean bHeadStart = !Character.isWhitespace(line.charAt(0));
            if (!USE_ABSTRACT_EX || bHeadStart || count < 4) {
                sb.append(line);
                sb.append(NEWLINE);
            }
            if (bHeadStart) {
                count = 0;
            } else {
                count++;
            }
        }
        return sb.toString().trim();
    }

    public AbstractLog(Log log) {
        this.log = log;
    }

    public static Log getLog(Log log) {
        return new AbstractLog(log);
    }

    public static Log getLog(Class<?> cls) {
        return new AbstractLog(LogFactory.getLog(cls));
    }

    @Override
    public void debug(Object arg0) {
        log.debug(arg0);
    }

    @Override
    public void debug(Object arg0, Throwable arg1) {
        if (USE_ABSTRACT_EX) {
            log.debug(arg0);
            log.debug(abstractTrace(arg1));
        } else {
            log.debug(arg0, arg1);
        }
    }

    @Override
    public void error(Object arg0) {
        if (arg0 instanceof Exception) {
            if (USE_ABSTRACT_EX) {
                log.error(abstractTrace((Exception) arg0));
            } else {
                log.error(arg0);
            }
        } else {
            log.error(arg0);
        }
    }

    @Override
    public void error(Object arg0, Throwable arg1) {
        if (USE_ABSTRACT_EX) {
            log.error(arg0);
            log.error(abstractTrace(arg1));
        } else {
            log.error(arg0, arg1);
        }
    }

    @Override
    public void fatal(Object arg0) {
        if (arg0 instanceof Exception) {
            if (USE_ABSTRACT_EX) {
                log.fatal(abstractTrace((Exception) arg0));
            } else {
                log.fatal(arg0);
            }
        } else {
            log.fatal(arg0);
        }
    }

    @Override
    public void fatal(Object arg0, Throwable arg1) {
        if (USE_ABSTRACT_EX) {
            log.fatal(arg0);
            log.fatal(abstractTrace(arg1));
        } else {
            log.fatal(arg0, arg1);
        }
    }

    @Override
    public void info(Object arg0) {
        log.info(arg0);
    }

    @Override
    public void info(Object arg0, Throwable arg1) {
        if (USE_ABSTRACT_EX) {
            log.info(arg0);
            log.info(abstractTrace(arg1));
        } else {
            log.info(arg0, arg1);
        }
    }

    @Override
    public boolean isDebugEnabled() {
        return log.isDebugEnabled();
    }

    @Override
    public boolean isErrorEnabled() {
        return log.isErrorEnabled();
    }

    @Override
    public boolean isFatalEnabled() {
        return log.isFatalEnabled();
    }

    @Override
    public boolean isInfoEnabled() {
        return log.isInfoEnabled();
    }

    @Override
    public boolean isTraceEnabled() {
        return log.isTraceEnabled();
    }

    @Override
    public boolean isWarnEnabled() {
        return log.isWarnEnabled();
    }

    @Override
    public void trace(Object arg0) {
        log.trace(arg0);
    }

    @Override
    public void trace(Object arg0, Throwable arg1) {
        if (USE_ABSTRACT_EX) {
            log.trace(arg0);
            log.trace(abstractTrace(arg1));
        } else {
            log.trace(arg0, arg1);
        }
    }

    @Override
    public void warn(Object arg0) {
        if (arg0 instanceof Exception) {
            if (USE_ABSTRACT_EX) {
                log.warn(abstractTrace((Exception) arg0));
            } else {
                log.warn((Exception) arg0);
            }
        } else {
            log.warn(arg0);
        }
    }

    @Override
    public void warn(Object arg0, Throwable arg1) {
        if (USE_ABSTRACT_EX) {
            log.warn(arg0);
            log.warn(abstractTrace(arg1));
        } else {
            log.warn(arg0, arg1);
        }
    }

}
