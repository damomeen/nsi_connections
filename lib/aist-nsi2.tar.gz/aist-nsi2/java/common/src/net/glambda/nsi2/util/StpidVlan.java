/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.util;

import org.apache.commons.logging.Log;

public class StpidVlan {

    protected static final Log logger = AbstractLog.getLog(StpidVlan.class);

    public final String fullStpid;
    public final String stpid;
    public final int vlan;

    public StpidVlan(String stpid) {
        this.fullStpid = stpid;
        int idx = stpid.indexOf(TypesBuilder.VLAN_MARK);
        if (idx > 0) {
            this.stpid = stpid.substring(0, idx);
            int v;
            try {
                v = Integer.parseInt(stpid.substring(idx + TypesBuilder.VLAN_MARK.length()));
            } catch (NumberFormatException e) {
                v = NSIConstants.VLANID_NOTUSE;
            }
            this.vlan = v;
        } else {
            this.stpid = stpid;
            this.vlan = NSIConstants.VLANID_NOTUSE;
        }
    }

}
