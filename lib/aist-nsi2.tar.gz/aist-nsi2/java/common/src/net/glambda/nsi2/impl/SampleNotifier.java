/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.impl;

import java.util.Calendar;

import org.apache.commons.logging.Log;
import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;
import org.ogf.schemas.nsi._2013._12.connection.types.DataPlaneStatusType;
import org.ogf.schemas.nsi._2013._12.connection.types.ErrorEventType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReserveTimeoutRequestType;

import net.glambda.nsi2.converter.ToNSI2;
import net.glambda.nsi2.util.AbstractLog;
import net.glambda.rms.DataPlaneState;
import net.glambda.rms.Notifier;

public class SampleNotifier implements Notifier {

    protected static final Log logger = AbstractLog.getLog(SampleNotifier.class);

    private final ProviderHandler provHandler;

    public SampleNotifier(ProviderHandler provHandler) {
        this.provHandler = provHandler;
    }

    @Override
    public void dataPlaneStateChange(String connectionId, DataPlaneState state) {
        dataPlaneStateChange(connectionId, state, true);
    }

    public void dataPlaneStateChange(String connectionId, DataPlaneState state, boolean isConsistent) {
        if (connectionId == null) {
            logger.warn("dataPlaneStateChange(): connectionId is null");
            return;
        }
        if (state == null) {
            logger.warn("dataPlaneStateChange(): state is null");
            return;
        }
        try {
            boolean isActive = (state == DataPlaneState.ACTIVE);
            StateMachine sm = provHandler.getStatusMachineManager().getStateMachine(connectionId);
            sm.dataPlaneStatusChange(state);
            ProviderArgument arg = sm.getReserveArg();
            if (arg == null) {
                return;
            }
            switch (state) {
            case ACTIVE:
            case INACTIVE:
                Calendar timeStamp = Calendar.getInstance();
                DataPlaneStatusType status = new DataPlaneStatusType();
                status.setActive(isActive);
                status.setVersion(sm.getCurrentVersion());
                status.setVersionConsistent(isConsistent);
                int notificationId = sm.getNewDataPlaneNotificationId();
                arg = new ProviderArgument(arg); // update correrationId
                provHandler.sendDataPlaneStateChange(arg, connectionId, notificationId, timeStamp,
                        status);
                break;
            default:
                break;
            }
        } catch (Exception e) {
            logger.warn(e);
        }
    }

    @Override
    public void errorEvent(String connectionId, net.glambda.rms.types.EventEnumType event,
            net.glambda.rms.types.TypeValuePairListType additionalInfo,
            net.glambda.rms.types.ServiceExceptionType serviceException) {
        if (connectionId == null) {
            logger.warn("errorEvent(): connectionId is null");
            return;
        }
        if (event == null) {
            logger.warn("errorEvent(): event is null");
            return;
        }
        try {
            StateMachine sm = provHandler.getStatusMachineManager().getStateMachine(connectionId);
            sm.setStatusByEvent(ToNSI2.convert(event));
            ProviderArgument arg = sm.getReserveArg();
            if (arg == null) {
                return;
            }
            Calendar timeStamp = Calendar.getInstance();
            ServiceException ex = new ServiceException("", ToNSI2.convert(serviceException));
            //
            ErrorEventType errorEvent = new ErrorEventType();
            errorEvent.setConnectionId(connectionId);
            errorEvent.setTimeStamp(timeStamp);
            errorEvent.setEvent(ToNSI2.convert(event));
            errorEvent.setAdditionalInfo(ToNSI2.convert(additionalInfo));
            errorEvent.setServiceException(ex.getFaultInfo());
            long notificationId = sm.addNotification(errorEvent);
            String originatingConnectionId = ""; // TODO,
            String originatingNSA = ""; // TODO
            //
            arg = new ProviderArgument(arg); // update correrationId
            provHandler.sendErrorEvent(arg, connectionId, notificationId, timeStamp,
                    errorEvent.getEvent(), originatingConnectionId, originatingNSA,
                    errorEvent.getAdditionalInfo(), ex);
        } catch (Exception e) {
            logger.warn(e);
        }
    }

    @Override
    public void reserveTimeout(String connectionId, int timeoutValue) {
        if (connectionId == null) {
            logger.warn("reserveTimeout(): connectionId is null");
            return;
        }
        try {
            StateMachine sm = provHandler.getStatusMachineManager().getStateMachine(connectionId);
            sm.setStatusByReserveTimeout();
            ProviderArgument arg = sm.getReserveArg();
            if (arg == null) {
                return;
            }
            Calendar timeStamp = Calendar.getInstance();
            //
            ReserveTimeoutRequestType timeout = new ReserveTimeoutRequestType();
            timeout.setConnectionId(connectionId);
            timeout.setTimeStamp(timeStamp);
            timeout.setTimeoutValue(timeoutValue);
            timeout.setOriginatingConnectionId(connectionId);
            timeout.setOriginatingNSA(arg.header().getProviderNSA());
            long notificationId = sm.addNotification(timeout);
            //
            arg = new ProviderArgument(arg); // update correrationId
            provHandler
                    .sendReserveTimeout(arg, connectionId, notificationId, timeStamp, timeoutValue,
                            timeout.getOriginatingConnectionId(), timeout.getOriginatingNSA());
        } catch (Exception e) {
            logger.warn(e);
        }
    }

}
