/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.requester;

import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

import net.glambda.nsi2.util.NSITextDump;
import net.glambda.nsi2.util.NSIUtil;
import net.glambda.pathfinder.IFTYPE;
import net.glambda.pathfinder.PathFinder;
import net.glambda.pathfinder.PathFindingCriteria;
import net.glambda.pathfinder.PathFindingResult;
import net.glambda.pathfinder.STP;
import net.glambda.pathfinder.SUPERNETWORK;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.OptionBuilder;
import org.apache.commons.cli.Options;
import org.ogf.schemas.nsi._2013._12.connection.provider.ConnectionProviderPort;
import org.ogf.schemas.nsi._2013._12.connection.types.ScheduleType;

public class PathFindOpe extends OpeBase {

    public final static String OPT_QUERYID = "q";
    public final static String OPT_SUPERNETTYPE = "sn";
    public final static String OPT_SRCSTP = "s";
    public final static String OPT_DSTSTP = "d";
    public final static String OPT_ISPROT = "p";
    public final static String OPT_PROTSRCSTP = "ps";
    public final static String OPT_PROTDSTSTP = "pd";

    public static final String BIND_NAME = "PathFinder";

    private final PathFinder finder;
    private PathFindingResult result = null;

    public PathFindOpe(String hostPort) throws Exception {
        String[] v = hostPort.split(":");
        if (v.length >= 2) {
            String name = (v.length >= 3 ? v[2] : BIND_NAME);
            System.out.println("try to connect to PathFinderServer: RMI host=" + v[0] + ", port="
                    + v[1] + ", bindName=" + name);
            Registry registry = LocateRegistry.getRegistry(v[0], Integer.parseInt(v[1]));
            this.finder = (PathFinder) registry.lookup(name);
            System.out.println("connected to PathFinderServer: RMI host=" + v[0] + ", port=" + v[1]
                    + ", bindName=" + name);
        } else {
            throw new Exception("invalid arg: " + hostPort);
        }
    }

    @Override
    protected void addOptions(Options options) {
        OptionBuilder.hasOptionalArgs(1);
        OptionBuilder.withArgName("queryId");
        OptionBuilder.withDescription("QueryID");
        options.addOption(OptionBuilder.create(OPT_QUERYID));

        OptionBuilder.hasArgs(1);
        OptionBuilder.isRequired(true);
        OptionBuilder.withArgName("superNetType");
        OptionBuilder.withDescription("SuperNetworkType (\"odu\", \"lambda\")");
        options.addOption(OptionBuilder.create(OPT_SUPERNETTYPE));

        OptionBuilder.hasOptionalArgs(4);
        OptionBuilder.isRequired(true);
        OptionBuilder.withArgName("networkid localid id width");
        OptionBuilder.withDescription("sourceSTP");
        OptionBuilder.withValueSeparator(' ');
        options.addOption(OptionBuilder.create(OPT_SRCSTP));

        OptionBuilder.hasOptionalArgs(4);
        OptionBuilder.isRequired(true);
        OptionBuilder.withArgName("networkid localid id width");
        OptionBuilder.withDescription("destinationSTP");
        OptionBuilder.withValueSeparator(' ');
        options.addOption(OptionBuilder.create(OPT_DSTSTP));

        addScheduleOption(options);

        OptionBuilder.hasOptionalArgs(1);
        OptionBuilder.withArgName("true|false");
        OptionBuilder
                .withDescription("isProtection (default true if protectionSrc/DestSTP is specified)");
        options.addOption(OptionBuilder.create(OPT_ISPROT));

        OptionBuilder.hasOptionalArgs(4);
        OptionBuilder.withArgName("protectionSourceSTP");
        OptionBuilder.withDescription("protection SourceSTP");
        OptionBuilder.withValueSeparator(' ');
        options.addOption(OptionBuilder.create(OPT_PROTSRCSTP));

        OptionBuilder.hasOptionalArgs(4);
        OptionBuilder.withArgName("protectionDestSTP");
        OptionBuilder.withDescription("protection DestSTP");
        OptionBuilder.withValueSeparator(' ');
        options.addOption(OptionBuilder.create(OPT_PROTDSTSTP));
    }

    private static SUPERNETWORK getSUPERNETWORK(CommandLine cmd) throws Exception {
        String v = cmd.getOptionValue(OPT_SUPERNETTYPE);
        if (v.equals("odu")) {
            return SUPERNETWORK.ODUNW;
        }
        if (v.equals("lambda")) {
            return SUPERNETWORK.LAMBDANW;
        }
        throw new Exception("invalid SUPERNETWORK: " + v);
    }

    private static STP makeSTP(CommandLine cmd, String cmdOpt, SUPERNETWORK superNetwork) {
        String[] v = cmd.getOptionValues(cmdOpt);
        if (v == null) {
            return null;
        }
        IFTYPE iftype = (superNetwork == SUPERNETWORK.ODUNW ? IFTYPE.ODU : IFTYPE.LAMBDA);
        String id = v[2];
        if (id.equals("null")) {
            id = null;
        }
        return new STP(v[0], v[1], iftype, id, Integer.parseInt(v[3]));
    }

    private PathFindingCriteria createCriteria(CommandLine cmd) throws Exception {
        String queryId = cmd.getOptionValue(OPT_QUERYID);
        if (queryId == null) {
            queryId = NSIUtil.getNewConnectionID();
        }
        SUPERNETWORK superNetwork = getSUPERNETWORK(cmd);
        ScheduleType schedule = makeSched(cmd);
        STP src = makeSTP(cmd, OPT_SRCSTP, superNetwork);
        STP dst = makeSTP(cmd, OPT_DSTSTP, superNetwork);
        STP protSrc = makeSTP(cmd, OPT_PROTSRCSTP, superNetwork);
        STP protDst = makeSTP(cmd, OPT_PROTDSTSTP, superNetwork);
        boolean isProtection;
        if (cmd.hasOption(OPT_ISPROT)) {
            isProtection = Boolean.parseBoolean(cmd.getOptionValue(OPT_ISPROT));
        } else {
            isProtection = (protSrc != null || protDst != null);
        }
        return new PathFindingCriteria(queryId, superNetwork, schedule.getStartTime(),
                schedule.getEndTime(), src, dst, isProtection, protSrc, protDst);
    }

    @Override
    void operation(ConnectionProviderPort provider, CommandLine cmd) throws Exception {
        PathFindingCriteria criteria = createCriteria(cmd);
        log(cmd, "**** PathFind request ****");
        log(cmd, NSITextDump.toString(criteria));
        try {
            result = finder.query(criteria);
            log(cmd, "**** PathFind result ****");
            log(cmd, NSITextDump.toString(result));
        } catch (RemoteException e) {
            e.printStackTrace();
        }
    }

    public PathFindingResult getLastResult() {
        return result;
    }
}
