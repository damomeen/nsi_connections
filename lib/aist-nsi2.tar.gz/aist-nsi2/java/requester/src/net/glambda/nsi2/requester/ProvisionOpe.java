/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.requester;

import net.glambda.nsi2.impl.ProviderPortWithHeader;
import net.glambda.nsi2.util.NSITextDump;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.Options;
import org.ogf.schemas.nsi._2013._12.connection.provider.ConnectionProviderPort;
import org.ogf.schemas.nsi._2013._12.framework.headers.CommonHeaderType;

public class ProvisionOpe extends OpeBase {

    protected void addOptions(Options options) {
        addConnIDOption(options);
    }

    @Override
    void operation(ConnectionProviderPort provider, CommandLine cmd) throws Exception {
        String connectionId = getConnectionID(cmd);
        CommonHeaderType header = getCommonHeader();
        ProviderPortWithHeader port = new ProviderPortWithHeader(header, provider);

        log(cmd, "**** provision request ****");
        log(cmd, NSITextDump.toString(header, connectionId));
        port.provision(connectionId);
    }

}
