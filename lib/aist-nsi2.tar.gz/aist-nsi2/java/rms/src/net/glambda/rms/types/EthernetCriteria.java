/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.rms.types;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import javax.xml.namespace.QName;

public class EthernetCriteria extends CriteriaBase {
    // NOTE: this class is created for ReservationRequestCriteriaType which has
    // one EthernetBaseType object in the any list.

    // from P2PServiceBaseType
    protected Long capacity;
    protected DirectionalityType directionality;
    protected Boolean symmetricPath;
    protected StpType sourceSTP;
    protected StpType destSTP;
    protected StpListType ero;

    // from EthernetBaseType
    protected Integer mtu;
    protected Long burstsize;

    // from EthernetVlanType
    protected Integer sourceVLAN;
    protected Integer destVLAN;

    private Map<QName, String> otherAttributes = new HashMap<QName, String>();

    public Calendar getStartTime() {
        return startTime;
    }

    public void setStartTime(Calendar startTime) {
        this.startTime = startTime;
    }

    public Calendar getEndTime() {
        return endTime;
    }

    public void setEndTime(Calendar endTime) {
        this.endTime = endTime;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public Long getCapacity() {
        return capacity;
    }

    public void setCapacity(Long capacity) {
        this.capacity = capacity;
    }

    public DirectionalityType getDirectionality() {
        return directionality;
    }

    public void setDirectionality(DirectionalityType directionality) {
        this.directionality = directionality;
    }

    public Boolean getSymmetricPath() {
        return symmetricPath;
    }

    public void setSymmetricPath(Boolean symmetricPath) {
        this.symmetricPath = symmetricPath;
    }

    public StpType getSourceSTP() {
        return sourceSTP;
    }

    public void setSourceSTP(StpType sourceSTP) {
        this.sourceSTP = sourceSTP;
    }

    public StpType getDestSTP() {
        return destSTP;
    }

    public void setDestSTP(StpType destSTP) {
        this.destSTP = destSTP;
    }

    public StpListType getEro() {
        return ero;
    }

    public void setEro(StpListType ero) {
        this.ero = ero;
    }

    public Integer getMtu() {
        return mtu;
    }

    public void setMtu(Integer mtu) {
        this.mtu = mtu;
    }

    public Long getBurstsize() {
        return burstsize;
    }

    public void setBurstsize(Long burstsize) {
        this.burstsize = burstsize;
    }

    public Map<QName, String> getOtherAttributes() {
        return otherAttributes;
    }

    public Integer getSourceVLAN() {
        return sourceVLAN;
    }

    public void setSourceVLAN(Integer sourceVLAN) {
        this.sourceVLAN = sourceVLAN;
    }

    public Integer getDestVLAN() {
        return destVLAN;
    }

    public void setDestVLAN(Integer destVLAN) {
        this.destVLAN = destVLAN;
    }

}
