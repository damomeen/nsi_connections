/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.topology.jsonutil;

import java.util.LinkedList;

import net.arnx.jsonic.JSON;
import net.glambda.nsi2.topology.NSA;
import net.glambda.nsi2.topology.STP;
import net.glambda.nsi2.topology.STPGroup;
import net.glambda.nsi2.topology.TopologyLoader;
import net.glambda.nsi2.util.NSIUtil;

public class DDS2JSON {

    private Topology nsa2topology(NSA nsa) {
        Topology topo = new Topology();
        topo.setNsa(nsa.ets());
        topo.setName(nsa.shortName());
        for (STP stp : nsa.biStps()) {
            topo.getPort().add(NSIUtil.dropPrefix(stp.stpid()));
        }
        // TODO temporary
        if ("aist.go.jp".equals(topo.getName())) {
            topo.getTerminal().add("aist.go.jp:2013:topology:term:video");
            topo.getTerminal().add("aist.go.jp:2013:topology:term:server");
        }
        return topo;
    }

    private void addRelation(DDSTopology ddsTopology, STP biStp) {
        if (!(biStp instanceof STPGroup)) {
            return;
        }
        if (((STPGroup) biStp).ports().isEmpty()) {
            System.err.println("WARN: " + biStp.stpid() + " has no ports");
            return;
        }
        STP conn = ((STPGroup) biStp).ports().getFirst().connectedTo();
        if (conn == null) {
            return;
        }
        STP biConn = STPGroup.findSTPGroup(conn.stpid());
        if (biConn == null) {
            return;
        }
        ddsTopology.addRelation(biStp.stpid(), biConn.stpid());
    }

    private void dds2json() throws Exception {
        LinkedList<NSA> nsaList = TopologyLoader.loadAll();
        DDSTopology ddsTopology = new DDSTopology();
        for (NSA nsa : nsaList) {
            if (!nsa.biStps().isEmpty()) {
                ddsTopology.getTopology().add(nsa2topology(nsa));
            }
        }
        // TODO temporary
        ddsTopology.addRelation("aist.go.jp:2013:topology:bi-ps",
                "aist.go.jp:2013:topology:term:server");
        ddsTopology.addRelation("aist.go.jp:2013:topology:bi-video",
                "aist.go.jp:2013:topology:term:video");

        for (NSA nsa : nsaList) {
            for (STP stp : nsa.biStps()) {
                addRelation(ddsTopology, stp);
            }
        }
        JSON json = new JSON();
        json.setPrettyPrint(true);
        json.setIndentText("    ");
        System.out.println(json.format(ddsTopology));
    }

    public static void main(String[] args) throws Exception {
        DDS2JSON app = new DDS2JSON();
        app.dds2json();
    }

}
