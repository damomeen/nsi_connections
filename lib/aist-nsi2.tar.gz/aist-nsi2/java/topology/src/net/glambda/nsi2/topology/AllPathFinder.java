/*
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package net.glambda.nsi2.topology;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;

import net.glambda.nsi2.util.AbstractLog;
import net.glambda.nsi2.util.ErrorID;
import net.glambda.nsi2.util.NSIExceptionUtil;

import org.apache.commons.logging.Log;
import org.ogf.schemas.nsi._2013._12.connection._interface.ServiceException;

public class AllPathFinder {

    protected static final Log logger = AbstractLog.getLog(AllPathFinder.class);

    protected static final String NSA_STP_FORMAT;

    static {
        int nsaLen = -1, stpLen = -1;
        try {
            LinkedList<NSA> nsaList = TopologyLoader.loadAll();
            for (NSA nsa : nsaList) {
                if (nsa.shortName().length() > nsaLen) {
                    nsaLen = nsa.shortName().length();
                }
                for (STP stp : nsa.biStps()) {
                    if (stp.stpid().length() > stpLen) {
                        stpLen = stp.stpid().length();
                    }
                }
            }
        } catch (Exception e) {
            logger.error(e);
            nsaLen = 20;
            stpLen = 30;
        }
        NSA_STP_FORMAT = makeNsaStpFormat(nsaLen, stpLen);
    }

    protected static class Pair<T, S> {
        public final T car;
        public final S cdr;

        public Pair(T car, S cdr) {
            this.car = car;
            this.cdr = cdr;
        }

        public String toString() {
            StringBuffer sb = new StringBuffer();
            sb.append(car.toString());
            sb.append("\t");
            sb.append(cdr.toString());
            return sb.toString();
        }
    }

    protected static class Result extends LinkedList<Pair<NSAPath, Path>> {
        private static final long serialVersionUID = 9167938291720200474L;

        void add(NSAPath n, Path p) {
            add(new Pair<NSAPath, Path>(n, p));
        }
    }

    protected static class Path extends LinkedList<STP> {
        private static final long serialVersionUID = -8167367740370720498L;

        public String toString() {
            StringBuffer sb = new StringBuffer();
            sb.append("[");
            boolean first = true;
            for (STP n : this) {
                if (!first)
                    sb.append(", ");
                else
                    first = false;
                sb.append("\"");
                sb.append(n.stpid());
                sb.append("\"");
            }
            sb.append("]");
            return sb.toString();
        }

        public Path copy() {
            return (Path) (this.clone());
        }
    }

    protected static class NSAPath extends LinkedList<NSA> {
        private static final long serialVersionUID = -1590289904487038979L;

        public String toString() {
            StringBuffer sb = new StringBuffer();
            sb.append("[");
            for (NSA n : this) {
                if (sb.length() > 1) {
                    sb.append(" ");
                }
                sb.append(n.shortName());
            }
            sb.append("]");
            return sb.toString();
        }

        public NSAPath copy() {
            return (NSAPath) this.clone();
        }
    }

    private void searchAll0(Path path, NSAPath nsaPath, NSA from, NSA to, Result result, int vlan,
            HashSet<String> ngSet) {
        NSAPath newNsaPath = nsaPath.copy();
        newNsaPath.addLast(from);
        if (from == to) {
            result.add(newNsaPath, path);
            return;
        }
        for (STP out : from.outStps()) {
            if (!out.isConnected()) {
                continue;
            }
            if (!out.vlans().hasVlan(vlan)) {
                if (!ngSet.contains(out.stpid())) {
                    System.err.println("VLAN.NG\t" + out.stpid() + "\t" + out.vlans().vlans());
                    ngSet.add(out.stpid());
                }
                continue;
            }
            if (out.connectedTo() == null) {
                continue;
            }
            if (!out.connectedTo().vlans().hasVlan(vlan)) {
                if (!ngSet.contains(out.connectedTo().stpid())) {
                    System.err.println("VLAN.NG\t" + out.connectedTo().stpid() + "\t"
                            + out.connectedTo().vlans().vlans());
                    ngSet.add(out.connectedTo().stpid());
                }
                continue;
            }
            NSA next = out.connectedTo().nsa();
            if (!nsaPath.contains(next)) {
                Path newPath = path.copy();
                newPath.addLast(out);
                newPath.addLast(out.connectedTo());
                searchAll0(newPath, newNsaPath, next, to, result, vlan, ngSet);
            }
        }
    }

    public Result searchAll(NSA from, NSA to, int vlan) {
        Result result = new Result();
        NSAPath nsaPath = new NSAPath();
        HashSet<String> ngSet = new HashSet<String>();
        searchAll0(new Path(), nsaPath, from, to, result, vlan, ngSet);
        return result;
    }

    private List<List<Term>> search(String connectionId, STP from, STP to, int vlan)
            throws ServiceException {
        if (!from.vlans().hasVlan(vlan)) {
            throw NSIExceptionUtil.makeServiceException(ErrorID.STP_RESOLUTION_ERROR, connectionId,
                    "VLAN.NG\t" + from.stpid() + "\t" + from.vlans().vlans());
        }
        if (!to.vlans().hasVlan(vlan)) {
            throw NSIExceptionUtil.makeServiceException(ErrorID.STP_RESOLUTION_ERROR, connectionId,
                    "VLAN.NG\t" + to.stpid() + "\t" + to.vlans().vlans());
        }
        STPGroup sgFrom = STPGroup.findSTPGroup(from.stpid());
        STPGroup sgTo = STPGroup.findSTPGroup(to.stpid());
        if (sgFrom == sgTo) {
            throw NSIExceptionUtil.makeServiceException(ErrorID.STP_RESOLUTION_ERROR, connectionId,
                    "from & to are same STPGroup: " + sgFrom.stpid());
        }
        List<List<Term>> pathList = new ArrayList<List<Term>>();
        if (from.nsa() == to.nsa()) {
            List<Term> path = new ArrayList<Term>();
            path.add(new Term(from, vlan));
            path.add(new Term(to, vlan));
            pathList.add(path);
            return pathList;
        }
        Result result = searchAll(from.nsa(), to.nsa(), vlan);
        for (Pair<NSAPath, Path> e : result) {
            if (STPGroup.findSTPGroup(e.cdr.peekFirst().stpid()) == sgFrom) {
                continue;
            }
            if (STPGroup.findSTPGroup(e.cdr.peekLast().stpid()) == sgTo) {
                continue;
            }
            ArrayList<Term> path = new ArrayList<Term>();
            path.add(new Term(from, vlan));
            for (STP stp : e.cdr) {
                path.add(new Term(STPGroup.findSTPGroup(stp.stpid()), vlan));
            }
            path.add(new Term(to, vlan));
            pathList.add(path);
        }
        return pathList;
    }

    public List<List<Term>> search(String connectionId, String startName, String endName, int vlan)
            throws ServiceException {
        STP from = STP.findSTP(startName);
        if (from == null) {
            throw NSIExceptionUtil.makeServiceException(ErrorID.UNKNOWN_STP, connectionId,
                    startName);
        }
        STP to = STP.findSTP(endName);
        if (to == null) {
            throw NSIExceptionUtil.makeServiceException(ErrorID.UNKNOWN_STP, connectionId, endName);
        }
        List<List<Term>> pathList = search(connectionId, from, to, vlan);
        if (pathList == null || pathList.isEmpty()) {
            throw NSIExceptionUtil.makeServiceException(ErrorID.NO_PATH_FOUND, connectionId);
        }
        return pathList;
    }

    // /////////////////////////////////////////////////////////////////////////

    private static class PathListComparator implements Comparator<List<Term>> {

        @Override
        public int compare(List<Term> o1, List<Term> o2) {
            int r = o1.size() - o2.size();
            if (r != 0) {
                return r;
            }
            for (int i = 0; i < o1.size(); i++) {
                Term t1 = o1.get(i);
                Term t2 = o2.get(i);
                STP s1 = t1.stp();
                STP s2 = t2.stp();
                r = (s1.nsa().name().compareTo(s2.nsa().name()));
                if (r != 0) {
                    return r;
                }
                r = t1.stpid().compareTo(t2.stpid());
                if (r != 0) {
                    return r;
                }
            }
            return 0;
        }
    }

    private static PathListComparator PATH_LIST_COMP = new PathListComparator();

    private static String makeNsaStpFormat(int nsaLen, int stpLen) {
        return String.format("%%d.%%d\t%%-%ds  %%-%ds  %%s\n", nsaLen, stpLen);
    }

    private static String makeNsaStpFormat(List<List<Term>> list) {
        int nsaLen = -1, stpLen = -1;
        for (List<Term> path : list) {
            for (Term term : path) {
                NSA nsa = term.stp().nsa();
                if (nsa.shortName().length() > nsaLen) {
                    nsaLen = nsa.shortName().length();
                }
                if (term.stpid().length() > stpLen) {
                    stpLen = term.stpid().length();
                }
            }
        }
        return makeNsaStpFormat(nsaLen, stpLen);
    }

    private static void output(List<List<Term>> list, int listStartIdx, String format) {
        Collections.sort(list, PATH_LIST_COMP);
        int listIdx = listStartIdx;
        for (List<Term> path : list) {
            System.out.println("*** Path " + listIdx + " ***");
            int stpIdx = 0;
            for (Term term : path) {
                STP stp = term.stp();
                String nsaName = ((stpIdx % 2) == 0 ? stp.nsa().shortName() : "");
                System.out.printf(format, listIdx, stpIdx, nsaName, term.stpid(), stp.vlans()
                        .vlans());
                stpIdx++;
            }
            listIdx++;
        }
    }

    public static void output(List<List<Term>> list, int listStartIdx) {
        String format = makeNsaStpFormat(list);
        output(list, listStartIdx, format);
    }

    private static boolean showStpHeader = true;
    private static int pathIdx = 0;

    private static void test(AllPathFinder finder, STP stpA, STP stpZ, int vlan) throws Exception {
        List<List<Term>> pathList = finder.search("", stpA.stpid(), stpZ.stpid(), vlan);
        if (showStpHeader) {
            System.out
                    .println("########################################################################");
            System.out.println("SRC LOCAL\t" + stpA.stpid());
            System.out.println("DST LOCAL\t" + stpZ.stpid());
            showStpHeader = false;
        }
        output(pathList, pathIdx, NSA_STP_FORMAT);
        pathIdx += pathList.size();
        System.out.println();
    }

    private static boolean isTerminal(STP stp) {
        if (stp instanceof STPGroup) {
            STPGroup sg = (STPGroup) stp;
            for (STP port : sg.ports()) {
                if (port.connectedToSTPName() != null) {
                    return false;
                }
            }
            return true;
        } else {
            return false;
        }
    }

    private static void test(AllPathFinder finder, NSA netA, NSA netZ, int minVlan, int maxVlan)
            throws Exception {
        for (STP stpA : netA.biStps()) {
            if (!isTerminal(stpA)) {
                continue;
            }
            for (STP stpZ : netZ.biStps()) {
                if (!isTerminal(stpZ)) {
                    continue;
                }
                if (stpA == stpZ) {
                    continue;
                }
                showStpHeader = true;
                pathIdx = 0;
                for (int vlan = minVlan; vlan <= maxVlan; vlan++) {
                    try {
                        test(finder, stpA, stpZ, vlan);
                    } catch (Exception e) {
                        // ignore "path not found"
                    }
                }
            }
        }
    }

    private static void test(int minVlan, int maxVlan) throws Exception {
        LinkedList<NSA> netList = TopologyLoader.loadAll();
        AllPathFinder finder = new AllPathFinder();
        int nNet = netList.size();
        for (int i = 0; i < nNet; i++) {
            NSA netA = netList.get(i);
            for (int j = i + 1; j < nNet; j++) {
                NSA netZ = netList.get(j);
                test(finder, netA, netZ, minVlan, maxVlan);
            }
        }
    }

    public static void main(String[] args) {
        int minVlan, maxVlan;
        if (args.length > 0) {
            minVlan = Integer.parseInt(args[0]);
            if (args.length >= 2) {
                maxVlan = Integer.parseInt(args[1]);
            } else {
                maxVlan = minVlan;
            }
            try {
                test(minVlan, maxVlan);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            System.err.println("Usage: java AllPathFinder minVlan [maxVlan]");
            System.exit(1);
        }
    }

}
