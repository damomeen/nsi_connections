/*
 * OGF NSI Requester API, ver. 2.0.sc
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package nsi2.reply;

import net.glambda.nsi2.impl.SampleRequesterWaitable.FailedMessage;
import nsi2.NSI2Client;

import org.ogf.schemas.nsi._2013._12.connection.types.ConnectionStatesType;
import org.ogf.schemas.nsi._2013._12.connection.types.ReservationConfirmCriteriaType;
import org.ogf.schemas.nsi._2013._12.framework.types.ServiceExceptionType;

public class ReserveReply {

    private final String connectionId;
    private final ReservationConfirmCriteriaType confirm;
    private final FailedMessage failed;

    private ReserveReply(String connectionId, ReservationConfirmCriteriaType confirm,
            FailedMessage failed) {
        this.connectionId = connectionId;
        this.confirm = confirm;
        this.failed = failed;
    }

    public ReserveReply(String connectionId) {
        this(connectionId, null, null);
    }

    public ReserveReply(String connectionId, ReservationConfirmCriteriaType confirm) {
        this(connectionId, confirm, null);
    }

    public ReserveReply(String connectionId, FailedMessage failed) {
        this(connectionId, null, failed);
    }

    /**
     * Get the connectionId of reserve reply.
     * 
     * <p>
     * You can get new allocated reservationId after calling
     * NSI2Client#reserve() under connectionId=null (which means new
     * reservation, not modification).
     * 
     * @return the connectionId of the reserve reply
     * @see NSI2Client#reserve(String, String, String,
     *      org.ogf.schemas.nsi._2013._12.connection.types.ReservationRequestCriteriaType)
     */
    public String getConnectionId() {
        return connectionId;
    }

    /**
     * Get the ReservationConfirmCriteriaType of the parameter of
     * reserveConfirmed
     * 
     * @return the ReservationConfirmCriteriaType object (if reserveConfirmed
     *         was received), or null (if reserveFailed was received).
     */
    public ReservationConfirmCriteriaType getConfirm() {
        return confirm;
    }

    /**
     * Get the ConnectionStatesType of the parameter of reserveFailed
     * 
     * @return the ConnectionStatesType object (if reserveFailed was
     *         received), or null (if reserveConfirmed was received).
     */
    public ConnectionStatesType getConnectionStates() {
        if (failed != null) {
            return failed.getConnectionStatesType();
        } else {
            return null;
        }
    }

    /**
     * Get the ServiceExceptionType of the parameter of reserveFailed
     * 
     * @return the ServiceExceptionType object (if reserveFailed was
     *         received), or null (if reserveConfirmed was received).
     */
    public ServiceExceptionType getServiceException() {
        if (failed != null) {
            return failed.getServiceExceptionType();
        } else {
            return null;
        }
    }

}
