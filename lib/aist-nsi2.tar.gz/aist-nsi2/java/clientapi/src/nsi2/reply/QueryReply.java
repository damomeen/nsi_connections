/*
 * OGF NSI Requester API, ver. 2.0.sc
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package nsi2.reply;

import java.util.List;

import org.ogf.schemas.nsi._2013._12.connection.types.QueryRecursiveResultType;
import org.ogf.schemas.nsi._2013._12.connection.types.QuerySummaryResultType;
import org.ogf.schemas.nsi._2013._12.framework.types.ServiceExceptionType;

public class QueryReply {

    private final List<QuerySummaryResultType> summary;
    private final List<QueryRecursiveResultType> recursive;
    private final ServiceExceptionType exception;

    private QueryReply(List<QuerySummaryResultType> summary,
            List<QueryRecursiveResultType> recursive, ServiceExceptionType exception) {
        this.summary = summary;
        this.recursive = recursive;
        this.exception = exception;
    }

    public QueryReply(List<QuerySummaryResultType> summary, List<QueryRecursiveResultType> recursive) {
        this(summary, recursive, null);
    }

    public QueryReply(ServiceExceptionType exception) {
        this(null, null, exception);
    }

    /**
     * Get the List of QuerySummaryResultType if querySymmary succeeded.
     * 
     * @return the List of QuerySummaryResultType (if succeeded), or null (if
     *         failed).
     */
    public List<QuerySummaryResultType> getSummary() {
        return summary;
    }

    /**
     * Get the List of QueryRecursiveResultType if queryRecursive succeeded.
     * 
     * @return the List of QueryRecursiveResultType (if succeeded), or null (if
     *         failed).
     */
    public List<QueryRecursiveResultType> getRecursive() {
        return recursive;
    }

    /**
     * Get the ServiceExceptionType if querySumamry or queryRecursive failed.
     * 
     * @return the ServiceExceptionType object (if failed), or null (if
     *         succeeded)
     */
    public ServiceExceptionType getException() {
        return exception;
    }

}
