/*
 * OGF NSI Requester API, ver. 2.0.sc
 * Copyright 2003-2013 National Institute of Advanced Industrial Science and Technology
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package nsi2.reply;

import org.ogf.schemas.nsi._2013._12.connection.types.ConnectionStatesType;
import org.ogf.schemas.nsi._2013._12.framework.types.ServiceExceptionType;

import net.glambda.nsi2.impl.SampleRequesterWaitable.FailedMessage;

public class ReserveCommitReply {

    private final FailedMessage failed;

    public ReserveCommitReply(FailedMessage failed) {
        this.failed = failed;
    }

    public ReserveCommitReply() {
        this(null);
    }

    /**
     * Get the ConnectionStatesType of the parameter of reserveCommitFailed
     * 
     * @return the ConnectionStatesType object (if reserveCommitFailed was
     *         received), or null (if reserveCommitConfirmed was received).
     */
    public ConnectionStatesType getConnectionStates() {
        if (failed != null) {
            return failed.getConnectionStatesType();
        } else {
            return null;
        }
    }

    /**
     * Get the ServiceExceptionType of the parameter of reserveCommitFailed
     * 
     * @return the ServiceExceptionType object (if reserveCommitFailed was
     *         received), or null (if reserveCommitConfirmed was received).
     */
    public ServiceExceptionType getServiceException() {
        if (failed != null) {
            return failed.getServiceExceptionType();
        } else {
            return null;
        }
    }

}
